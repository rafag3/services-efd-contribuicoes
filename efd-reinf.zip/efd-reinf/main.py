"""
main.py — EFD-REINF | Sompo Seguros
Interface gráfica para assinatura e envio de eventos à Receita Federal.
"""

import os
import sys
import json
import threading
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
from pathlib import Path
from datetime import datetime

# Garante que os imports funcionem tanto rodando direto quanto via .exe (PyInstaller)
if getattr(sys, "frozen", False):
    BASE_DIR = Path(sys.executable).parent
else:
    BASE_DIR = Path(__file__).resolve().parent

sys.path.insert(0, str(BASE_DIR))

from core.config_manager import carregar_config, get_tp_amb, get_cert_path
from core.assinar import assinar_xml
from core.enviar import enviar_lote

# ─────────────────────────────────────────
# Paleta Sompo
# ─────────────────────────────────────────
C_RED        = "#C41230"
C_RED_DARK   = "#8B0C1E"
C_RED_HOVER  = "#E01535"
C_GRAY_DARK  = "#2B2B2B"
C_GRAY_MID   = "#3C3C3C"
C_GRAY_PANEL = "#F2F2F2"
C_GRAY_LINE  = "#DCDCDC"
C_WHITE      = "#FFFFFF"
C_TEXT_DARK  = "#1A1A1A"
C_TEXT_MID   = "#555555"
C_TEXT_LIGHT = "#888888"
C_GREEN      = "#1E7E34"
C_ORANGE     = "#C07000"
C_LOG_BG     = "#1C1C1C"
C_LOG_FG     = "#E8E8E8"
C_LOG_GREEN  = "#4EC94E"
C_LOG_YELLOW = "#F0C060"
C_LOG_RED    = "#FF6060"

FONT_TITLE  = ("Segoe UI", 11, "bold")
FONT_LABEL  = ("Segoe UI", 9)
FONT_SMALL  = ("Segoe UI", 8)
FONT_MONO   = ("Consolas", 9)
FONT_HEADER = ("Segoe UI", 14, "bold")
FONT_SUB    = ("Segoe UI", 8)


# ─────────────────────────────────────────
# Botão customizado com hover
# ─────────────────────────────────────────
class SompoButton(tk.Canvas):
    def __init__(self, parent, text, command, width=160, height=38,
                 bg=C_RED, bg_hover=C_RED_HOVER, fg=C_WHITE,
                 icon="", disabled=False, **kwargs):
        super().__init__(parent, width=width, height=height,
                         bg=parent.cget("bg"), highlightthickness=0,
                         cursor="hand2" if not disabled else "arrow", **kwargs)
        self._text = text
        self._icon = icon
        self._command = command
        self._bg = bg
        self._bg_hover = bg_hover
        self._fg = fg
        self._btn_w = width   # _w é reservado pelo tkinter — usar _btn_w
        self._btn_h = height  # _h é reservado pelo tkinter — usar _btn_h
        self._disabled = disabled
        self._hover = False

        # Usar after_idle para garantir que o widget esteja
        # totalmente registrado no Tcl antes do primeiro draw
        # (evita TclError: invalid command name no Python 3.12/Windows)
        self.after_idle(lambda: self._draw(self._bg))
        self.bind("<Enter>", self._on_enter)
        self.bind("<Leave>", self._on_leave)
        self.bind("<Button-1>", self._on_click)

    def _draw(self, color):
        try:
            self.delete("all")
        except tk.TclError:
            return
        r = 5
        x1, y1, x2, y2 = 1, 1, self._btn_w - 1, self._btn_h - 1
        # Rounded rectangle
        self.create_arc(x1, y1, x1+r*2, y1+r*2, start=90, extent=90, fill=color, outline=color)
        self.create_arc(x2-r*2, y1, x2, y1+r*2, start=0, extent=90, fill=color, outline=color)
        self.create_arc(x1, y2-r*2, x1+r*2, y2, start=180, extent=90, fill=color, outline=color)
        self.create_arc(x2-r*2, y2-r*2, x2, y2, start=270, extent=90, fill=color, outline=color)
        self.create_rectangle(x1+r, y1, x2-r, y2, fill=color, outline=color)
        self.create_rectangle(x1, y1+r, x2, y2-r, fill=color, outline=color)

        label = f"{self._icon}  {self._text}" if self._icon else self._text
        alpha = self._fg if not self._disabled else "#999999"
        self.create_text(self._btn_w//2, self._btn_h//2, text=label,
                         fill=alpha, font=FONT_LABEL, anchor="center")

    def _on_enter(self, e):
        if not self._disabled:
            self._draw(self._bg_hover)

    def _on_leave(self, e):
        if not self._disabled:
            self._draw(self._bg)

    def _on_click(self, e):
        if not self._disabled and self._command:
            self._command()

    def set_disabled(self, val: bool):
        self._disabled = val
        self.configure(cursor="arrow" if val else "hand2")
        self._draw(self._bg)


# ─────────────────────────────────────────
# Janela principal
# ─────────────────────────────────────────
class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("EFD-REINF — Sompo Seguros")
        self.resizable(False, False)
        self.configure(bg=C_GRAY_PANEL)
        self._center(900, 620)
        self._set_icon()

        self.config_data = {}
        self.xml_path = tk.StringVar()
        self.xml_assinado_path: Path = None
        self._lock = threading.Lock()

        self._build_ui()
        self._carregar_config_auto()

    def _center(self, w, h):
        self.update_idletasks()
        sw = self.winfo_screenwidth()
        sh = self.winfo_screenheight()
        x = (sw - w) // 2
        y = (sh - h) // 2
        self.geometry(f"{w}x{h}+{x}+{y}")

    def _set_icon(self):
        """Tenta carregar ícone da pasta assets/."""
        ico = BASE_DIR / "assets" / "icon.ico"
        if ico.exists():
            try:
                self.iconbitmap(str(ico))
            except Exception:
                pass

    # ──────────────────────────────────────
    # Layout
    # ──────────────────────────────────────
    def _build_ui(self):
        self._build_header()
        body = tk.Frame(self, bg=C_GRAY_PANEL)
        body.pack(fill="both", expand=True, padx=16, pady=(0, 12))

        left  = tk.Frame(body, bg=C_GRAY_PANEL, width=380)
        right = tk.Frame(body, bg=C_GRAY_PANEL)
        left.pack(side="left", fill="both", padx=(0, 10))
        right.pack(side="left", fill="both", expand=True)
        left.pack_propagate(False)

        self._build_config_panel(left)
        self._build_xml_panel(left)
        self._build_actions(left)
        self._build_log(right)
        self._build_status_bar()

    def _build_header(self):
        hdr = tk.Frame(self, bg=C_RED, height=68)
        hdr.pack(fill="x")
        hdr.pack_propagate(False)

        # Logo text (substitua por imagem se tiver assets/logo.png)
        logo_frame = tk.Frame(hdr, bg=C_RED)
        logo_frame.pack(side="left", padx=20, pady=10)

        logo_path = BASE_DIR / "assets" / "logo.png"
        if logo_path.exists():
            try:
                from PIL import Image, ImageTk
                img = Image.open(str(logo_path)).resize((120, 40), Image.LANCZOS)
                self._logo_img = ImageTk.PhotoImage(img)
                tk.Label(logo_frame, image=self._logo_img, bg=C_RED).pack()
            except Exception:
                self._build_logo_text(logo_frame)
        else:
            self._build_logo_text(logo_frame)

        # Divider vertical
        tk.Frame(hdr, bg="#E03050", width=1).pack(side="left", fill="y", padx=14, pady=12)

        # Título do sistema
        title_frame = tk.Frame(hdr, bg=C_RED)
        title_frame.pack(side="left", pady=10)
        tk.Label(title_frame, text="EFD-REINF", font=FONT_HEADER,
                 fg=C_WHITE, bg=C_RED).pack(anchor="w")
        tk.Label(title_frame, text="Escrituração Fiscal Digital — Envio de Eventos",
                 font=FONT_SUB, fg="#FFAAAA", bg=C_RED).pack(anchor="w")

        # Badge ambiente (canto direito)
        self._badge_var = tk.StringVar(value="● PROD. RESTRITA")
        self._badge_lbl = tk.Label(hdr, textvariable=self._badge_var,
                                   font=("Segoe UI", 8, "bold"),
                                   fg="#FFE08A", bg=C_RED_DARK,
                                   padx=10, pady=4, relief="flat")
        self._badge_lbl.pack(side="right", padx=18, pady=20)

    def _build_logo_text(self, parent):
        """Fallback: desenha logo SOMPO em texto estilizado."""
        c = tk.Canvas(parent, width=100, height=42, bg=C_RED,
                      highlightthickness=0)
        c.pack()
        # Bloco vermelho escuro simulando o ícone da marca
        c.create_rectangle(0, 8, 32, 40, fill=C_RED_DARK, outline="")
        c.create_text(16, 24, text="S", font=("Segoe UI", 14, "bold"),
                      fill=C_WHITE)
        c.create_text(68, 22, text="SOMPO", font=("Segoe UI", 12, "bold"),
                      fill=C_WHITE)
        c.create_text(68, 36, text="SEGUROS", font=("Segoe UI", 7),
                      fill="#FFCCCC")

    def _card(self, parent, title):
        """Cria um card branco com título."""
        outer = tk.Frame(parent, bg=C_GRAY_PANEL)
        outer.pack(fill="x", pady=(0, 10))
        header = tk.Frame(outer, bg=C_RED, height=26)
        header.pack(fill="x")
        header.pack_propagate(False)
        tk.Label(header, text=f"  {title}", font=("Segoe UI", 9, "bold"),
                 fg=C_WHITE, bg=C_RED, anchor="w").pack(fill="x", pady=4)
        inner = tk.Frame(outer, bg=C_WHITE, padx=12, pady=10,
                         relief="flat", bd=1,
                         highlightbackground=C_GRAY_LINE,
                         highlightthickness=1)
        inner.pack(fill="x")
        return inner

    def _build_config_panel(self, parent):
        card = self._card(parent, "⚙  Configuração")

        self._cnpj_var    = tk.StringVar()
        self._amb_var     = tk.StringVar()
        self._cert_var    = tk.StringVar()
        self._razao_var   = tk.StringVar()

        rows = [
            ("CNPJ",        self._cnpj_var),
            ("Razão Social", self._razao_var),
            ("Ambiente",    self._amb_var),
            ("Certificado", self._cert_var),
        ]
        for lbl, var in rows:
            row = tk.Frame(card, bg=C_WHITE)
            row.pack(fill="x", pady=2)
            tk.Label(row, text=f"{lbl}:", font=FONT_SMALL,
                     fg=C_TEXT_MID, bg=C_WHITE, width=12, anchor="w").pack(side="left")
            tk.Label(row, textvariable=var, font=FONT_SMALL,
                     fg=C_TEXT_DARK, bg=C_WHITE, anchor="w",
                     wraplength=220).pack(side="left", fill="x", expand=True)

        btn_row = tk.Frame(card, bg=C_WHITE)
        btn_row.pack(fill="x", pady=(8, 2))
        SompoButton(btn_row, "Recarregar Config", self._carregar_config_auto,
                    width=160, height=30, bg=C_GRAY_MID,
                    bg_hover="#555555").pack(side="left")

    def _build_xml_panel(self, parent):
        card = self._card(parent, "📄  Arquivo XML")

        row = tk.Frame(card, bg=C_WHITE)
        row.pack(fill="x", pady=2)
        entry = tk.Entry(row, textvariable=self.xml_path, font=FONT_SMALL,
                         fg=C_TEXT_DARK, bg="#F9F9F9",
                         relief="solid", bd=1, width=34)
        entry.pack(side="left", fill="x", expand=True, ipady=4)

        SompoButton(row, "...", self._browse_xml,
                    width=32, height=28, bg=C_GRAY_MID,
                    bg_hover="#555555").pack(side="left", padx=(6, 0))

        self._xml_info = tk.Label(card, text="Nenhum arquivo selecionado.",
                                  font=FONT_SMALL, fg=C_TEXT_LIGHT, bg=C_WHITE,
                                  anchor="w")
        self._xml_info.pack(fill="x", pady=(4, 0))

    def _build_actions(self, parent):
        card = self._card(parent, "🚀  Ações")

        self._btn_assinar = SompoButton(card, "Assinar XML", self._run_assinar,
                                        width=168, height=36, icon="✍")
        self._btn_assinar.pack(side="left", padx=(0, 8))

        self._btn_enviar = SompoButton(card, "Enviar à RF", self._run_enviar,
                                       width=168, height=36, icon="📤",
                                       bg=C_GRAY_MID, bg_hover="#555555")
        self._btn_enviar.pack(side="left")

    def _build_log(self, parent):
        hdr = tk.Frame(parent, bg=C_RED, height=26)
        hdr.pack(fill="x")
        hdr.pack_propagate(False)
        tk.Label(hdr, text="  📋  Log de Execução", font=("Segoe UI", 9, "bold"),
                 fg=C_WHITE, bg=C_RED, anchor="w").pack(fill="x", pady=4)

        log_frame = tk.Frame(parent, bg=C_LOG_BG, padx=1, pady=1)
        log_frame.pack(fill="both", expand=True)

        self._log = tk.Text(
            log_frame, bg=C_LOG_BG, fg=C_LOG_FG,
            font=FONT_MONO, relief="flat", bd=0,
            state="disabled", wrap="word",
            selectbackground=C_RED_DARK, padx=10, pady=8
        )
        scrollbar = tk.Scrollbar(log_frame, command=self._log.yview,
                                 bg=C_GRAY_MID, troughcolor=C_LOG_BG,
                                 width=10)
        self._log.configure(yscrollcommand=scrollbar.set)
        scrollbar.pack(side="right", fill="y")
        self._log.pack(fill="both", expand=True)

        # Tags de cor
        self._log.tag_config("ok",    foreground=C_LOG_GREEN)
        self._log.tag_config("warn",  foreground=C_LOG_YELLOW)
        self._log.tag_config("error", foreground=C_LOG_RED)
        self._log.tag_config("info",  foreground=C_LOG_FG)
        self._log.tag_config("ts",    foreground="#666666")

        btn_row = tk.Frame(parent, bg=C_GRAY_PANEL)
        btn_row.pack(fill="x", pady=(6, 0))
        SompoButton(btn_row, "Limpar Log", self._limpar_log,
                    width=110, height=28, bg=C_GRAY_MID,
                    bg_hover="#555555").pack(side="right")

    def _build_status_bar(self):
        bar = tk.Frame(self, bg=C_GRAY_DARK, height=24)
        bar.pack(fill="x", side="bottom")
        bar.pack_propagate(False)
        self._status_var = tk.StringVar(value="Pronto.")
        tk.Label(bar, textvariable=self._status_var, font=FONT_SMALL,
                 fg="#AAAAAA", bg=C_GRAY_DARK, anchor="w",
                 padx=12).pack(side="left", fill="y")

        tk.Label(bar, text="Sompo Seguros  •  Fiscal",
                 font=FONT_SMALL, fg="#666666", bg=C_GRAY_DARK,
                 padx=12).pack(side="right", fill="y")

    # ──────────────────────────────────────
    # Lógica
    # ──────────────────────────────────────
    def _log_write(self, msg: str):
        """Escreve no log com colorização automática, thread-safe."""
        def _do():
            self._log.configure(state="normal")
            ts = datetime.now().strftime("%H:%M:%S")
            self._log.insert("end", f"[{ts}]  ", "ts")

            if msg.startswith("✅") or msg.startswith("🎉"):
                tag = "ok"
            elif msg.startswith("⚠") or msg.startswith("📬"):
                tag = "warn"
            elif msg.startswith("❌"):
                tag = "error"
            else:
                tag = "info"

            self._log.insert("end", msg + "\n", tag)
            self._log.configure(state="disabled")
            self._log.see("end")

        self.after(0, _do)

    def _limpar_log(self):
        self._log.configure(state="normal")
        self._log.delete("1.0", "end")
        self._log.configure(state="disabled")

    def _set_status(self, msg: str):
        self.after(0, lambda: self._status_var.set(msg))

    def _carregar_config_auto(self):
        cfg_path = BASE_DIR / "config" / "config.json"
        try:
            self.config_data = carregar_config(str(cfg_path))
            self._cnpj_var.set(self.config_data.get("cnpj", "—"))
            self._razao_var.set(self.config_data.get("razao_social", "—"))
            self._amb_var.set(self.config_data.get("ambiente", "—"))
            cert = self.config_data.get("certificado", "—")
            self._cert_var.set(Path(cert).name)

            amb = self.config_data.get("ambiente", "")
            if amb == "producao":
                self._badge_var.set("● PRODUÇÃO")
                self._badge_lbl.configure(fg="#FF8080")
            else:
                self._badge_var.set("● PROD. RESTRITA")
                self._badge_lbl.configure(fg="#FFE08A")

            self._log_write("✅ Configuração carregada com sucesso.")
            self._set_status("Config carregada.")
        except Exception as e:
            self._log_write(f"❌ Erro ao carregar config: {e}")
            self._set_status("Erro na configuração.")
            messagebox.showerror("Erro de Configuração", str(e))

    def _browse_xml(self):
        path = filedialog.askopenfilename(
            title="Selecionar XML EFD-REINF",
            initialdir=BASE_DIR / "xmls",
            filetypes=[("Arquivos XML", "*.xml"), ("Todos", "*.*")]
        )
        if path:
            self.xml_path.set(path)
            size = os.path.getsize(path)
            name = Path(path).name
            self._xml_info.configure(
                text=f"📄 {name}  ({size:,} bytes)",
                fg=C_TEXT_DARK
            )
            self._log_write(f"📄 XML selecionado: {name}")

    def _run_assinar(self):
        if not self.config_data:
            messagebox.showwarning("Atenção", "Carregue a configuração primeiro.")
            return
        xml_str = self.xml_path.get().strip()
        if not xml_str:
            messagebox.showwarning("Atenção", "Selecione um arquivo XML para assinar.")
            return

        self._btn_assinar.set_disabled(True)
        self._btn_enviar.set_disabled(True)
        self._set_status("Assinando XML...")
        self._log_write("─" * 50)
        self._log_write("✍  Iniciando processo de assinatura XMLDSig...")

        def _tarefa():
            try:
                xml_path  = Path(xml_str)
                cert_path = get_cert_path(self.config_data)
                senha     = self.config_data["senha_certificado"]

                self._log_write(f"📂 XML: {xml_path.name}")
                self._log_write(f"🔐 Certificado: {cert_path.name}")

                output = assinar_xml(xml_path, cert_path, senha)
                self.xml_assinado_path = output

                self._log_write(f"✅ XML assinado salvo em: {output.name}")
                self._log_write("🎉 Assinatura concluída! Pronto para envio.")
                self._set_status("Assinatura concluída.")
                self.after(0, lambda: messagebox.showinfo(
                    "Sucesso", f"XML assinado com sucesso!\n\n{output.name}"
                ))
            except Exception as e:
                self._log_write(f"❌ Falha na assinatura: {e}")
                self._set_status("Erro na assinatura.")
                self.after(0, lambda: messagebox.showerror("Erro", str(e)))
            finally:
                self.after(0, lambda: self._btn_assinar.set_disabled(False))
                self.after(0, lambda: self._btn_enviar.set_disabled(False))

        threading.Thread(target=_tarefa, daemon=True).start()

    def _run_enviar(self):
        if not self.config_data:
            messagebox.showwarning("Atenção", "Carregue a configuração primeiro.")
            return
        if not self.xml_assinado_path or not self.xml_assinado_path.exists():
            messagebox.showwarning(
                "Atenção",
                "Nenhum XML assinado disponível.\nAssine o XML antes de enviar."
            )
            return

        amb = self.config_data.get("ambiente", "")
        if amb == "producao":
            if not messagebox.askyesno(
                "Confirmar Envio — PRODUÇÃO",
                "⚠️  Você está enviando para o ambiente de PRODUÇÃO da Receita Federal.\n\n"
                "Deseja continuar?"
            ):
                return

        self._btn_assinar.set_disabled(True)
        self._btn_enviar.set_disabled(True)
        self._set_status("Enviando para a Receita Federal...")
        self._log_write("─" * 50)
        self._log_write(f"📤 Iniciando envio — ambiente: {amb.upper()}")

        def _tarefa():
            try:
                cert_path = get_cert_path(self.config_data)
                senha     = self.config_data["senha_certificado"]
                output    = BASE_DIR / "xmls"

                resp_path = enviar_lote(
                    self.xml_assinado_path,
                    cert_path, senha, amb,
                    output_dir=output,
                    log_callback=self._log_write
                )
                self._log_write(f"🎉 Envio finalizado! Resposta: {resp_path.name}")
                self._set_status("Envio concluído.")
                self.after(0, lambda: messagebox.showinfo(
                    "Enviado",
                    f"Lote enviado com sucesso!\n\nResposta salva em:\n{resp_path.name}"
                ))
            except Exception as e:
                self._log_write(f"❌ Falha no envio: {e}")
                self._set_status("Erro no envio.")
                self.after(0, lambda: messagebox.showerror("Erro de Envio", str(e)))
            finally:
                self.after(0, lambda: self._btn_assinar.set_disabled(False))
                self.after(0, lambda: self._btn_enviar.set_disabled(False))

        threading.Thread(target=_tarefa, daemon=True).start()


# ─────────────────────────────────────────
if __name__ == "__main__":
    app = App()
    app.mainloop()
