# EFD-REINF — Sompo Seguros

Ferramenta de assinatura e envio de eventos EFD-REINF ao WebService da Receita Federal do Brasil.

---

## Estrutura do Projeto

```
efd-reinf/
├── main.py                        ← GUI principal (entry point)
├── build.bat                      ← Compila o .exe com PyInstaller
├── requirements.txt               ← Dependências Python
│
├── core/
│   ├── assinar.py                 ← Assinatura XMLDSig (padrão RF)
│   ├── enviar.py                  ← Envio SOAP ao WebService
│   └── config_manager.py         ← Carrega e valida config.json
│
├── config/
│   └── config.json               ← CNPJ, ambiente, certificado, contato
│
├── xmls/
│   ├── R-1000.xml                ← Evento de exemplo (edite conforme necessário)
│   └── (outputs gerados aqui)
│
├── certificado/
│   ├── SERVICES.pfx.pfx          ← Certificado A1 (.pfx)
│   └── converter_certificado.bat ← Converte .pfx → .crt + .key via OpenSSL
│
└── assets/
    ├── logo.png                  ← Logo Sompo (opcional — 120x40px recomendado)
    └── icon.ico                  ← Ícone da janela/exe (opcional)
```

---

## Pré-requisitos

- Python 3.10+
- OpenSSL instalado e no PATH (necessário para `enviar.py`)

```
pip install -r requirements.txt
```

---

## Como usar

### 1. Configurar
Edite `config/config.json` com os dados corretos.

### 2. Rodar direto
```bash
python main.py
```

### 3. Gerar .exe
```
build.bat
```
O executável será gerado em `dist/EFD-REINF_Sompo.exe`.

---

## Fluxo de uso na GUI

1. **Recarregar Config** — valida o config.json
2. **Selecionar XML** — escolha o arquivo do evento (ex: R-1000.xml)
3. **Assinar XML** — gera `R-1000_assinado.xml` com XMLDSig correto
4. **Enviar à RF** — envia via SOAP ao WebService da Receita

---

## Sobre a assinatura

A assinatura segue o padrão **XMLDSig Enveloped** exigido pela Receita Federal:
- Algoritmo: RSA-SHA1
- Digest: SHA-1
- Canonicalização: C14N
- Referência: URI="#id_do_evento"

---

## Ambientes

| Ambiente           | Host                                           |
|--------------------|------------------------------------------------|
| producao_restrita  | preprodefdr-reinf.receita.fazenda.gov.br       |
| producao           | reinf.receita.fazenda.gov.br                   |

---

## Adicionando o logo Sompo

Coloque `assets/logo.png` (120×40px) — a GUI carrega automaticamente.
Se não existir, exibe o logo em texto como fallback.
