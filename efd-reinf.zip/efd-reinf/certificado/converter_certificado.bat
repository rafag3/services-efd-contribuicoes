@echo off
echo 🔄 Convertendo certificado...

openssl pkcs12 -in "S:\FISCAL\1-FEDERAIS\IRRF-CSRF\02_Services (5000)\00. AUTOMAÇÃO FED\efd-reinf\certificado\SERVICES.pfx.pfx" -clcerts -nokeys -out certificado.crt -passin pass:Sompo@2025
openssl pkcs12 -in "S:\FISCAL\1-FEDERAIS\IRRF-CSRF\02_Services (5000)\00. AUTOMAÇÃO FED\efd-reinf\certificado\SERVICES.pfx.pfx" -nocerts -nodes -out chave.key -passin pass:Sompo@2025

echo ✅ Conversão concluída!
echo Arquivos gerados: certificado.crt e chave.key
pause
