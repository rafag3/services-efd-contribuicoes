@echo off
title EFD-REINF - Build .exe Sompo
color 4F

echo.
echo  ===================================================
echo   SOMPO SEGUROS - Build EFD-REINF
echo  ===================================================
echo.

REM Verificar se Python esta disponivel
python --version >nul 2>&1
if errorlevel 1 (
    echo  [ERRO] Python nao encontrado. Instale Python 3.10+.
    pause
    exit /b 1
)

REM Instalar dependencias
echo  [1/3] Instalando dependencias...
pip install -r requirements.txt --quiet
if errorlevel 1 (
    echo  [ERRO] Falha ao instalar dependencias.
    pause
    exit /b 1
)
echo  OK.

REM Criar pasta assets se nao existir
if not exist assets mkdir assets

REM Montar comando PyInstaller
echo  [2/3] Compilando .exe com PyInstaller...

set ICON_ARG=
if exist assets\icon.ico (
    set ICON_ARG=--icon=assets/icon.ico
)

set ADD_DATA=--add-data "config;config" ^
             --add-data "xmls;xmls" ^
             --add-data "certificado;certificado" ^
             --add-data "assets;assets"

pyinstaller ^
    --onefile ^
    --windowed ^
    --name "EFD-REINF_Sompo" ^
    %ICON_ARG% ^
    %ADD_DATA% ^
    --hidden-import cryptography ^
    --hidden-import lxml ^
    --hidden-import lxml.etree ^
    main.py

if errorlevel 1 (
    echo  [ERRO] Falha na compilacao. Verifique o log acima.
    pause
    exit /b 1
)

echo  [3/3] Copiando arquivos necessarios para dist/...

REM Copiar pastas de dados para junto do .exe
xcopy /E /I /Y config    dist\config    >nul
xcopy /E /I /Y xmls      dist\xmls      >nul
xcopy /E /I /Y assets    dist\assets    >nul

REM Criar pasta certificado (sem copiar o .pfx — por seguranca)
if not exist dist\certificado mkdir dist\certificado
echo  COLOQUE O CERTIFICADO .PFX AQUI > dist\certificado\LEIA-ME.txt

echo.
echo  ===================================================
echo   .exe gerado em: dist\EFD-REINF_Sompo.exe
echo  ===================================================
echo.
pause
