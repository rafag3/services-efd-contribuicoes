"""blocoM_builder.py — Monta M001, M200, M210, M600, M610, M990"""

from config.constantes import F100_FIXAS, A170_ALIQ_PIS, A170_ALIQ_COFINS
from domain.models import NotaFiscal, RegistroF600
from domain.formatadores import montar_linha, fmt_valor


def build_blocoM(notas: list[NotaFiscal], f600s: list[RegistroF600] = None,
                 f100_data: list[dict] = None) -> list[str]:
    f100 = f100_data if f100_data is not None else F100_FIXAS
    linhas = []
    linhas.append("|M001|0|")

    base_cst01 = round(sum(n.vl_doc for n in notas), 2)
    base_cst02 = round(sum(f["VL_BC_PIS"] for f in f100), 2)

    pis_cst01 = round(base_cst01 * A170_ALIQ_PIS / 100, 2)
    pis_cst02 = round(sum(f["VL_PIS"] for f in f100), 2)
    total_pis  = round(pis_cst01 + pis_cst02, 2)
    ret_nc_pis = round(sum(f.vl_ret_pis for f in f600s), 2) if f600s else 0.0

    linhas.append(montar_linha(
        "M200",
        fmt_valor(total_pis), "0", "0", fmt_valor(total_pis),
        fmt_valor(ret_nc_pis), "0", "0", "0", "0", "0", "0", "0",
    ))

    if base_cst02 > 0:
        linhas.append(montar_linha(
            "M210", "02",
            fmt_valor(base_cst02), fmt_valor(base_cst02), "0", "0", fmt_valor(base_cst02),
            "0,65", "0", "", fmt_valor(pis_cst02), "0", "0", "0", "0", fmt_valor(pis_cst02),
        ))
    if base_cst01 > 0:
        linhas.append(montar_linha(
            "M210", "01",
            fmt_valor(base_cst01), fmt_valor(base_cst01), "0", "0", fmt_valor(base_cst01),
            "1,65", "0", "", fmt_valor(pis_cst01), "0", "0", "0", "0", fmt_valor(pis_cst01),
        ))

    cofins_cst01 = round(base_cst01 * A170_ALIQ_COFINS / 100, 2)
    cofins_cst02 = round(sum(f["VL_COFINS"] for f in f100), 2)
    total_cofins  = round(cofins_cst01 + cofins_cst02, 2)
    ret_nc_cofins = round(sum(f.vl_ret_cofins for f in f600s), 2) if f600s else 0.0

    linhas.append(montar_linha(
        "M600",
        fmt_valor(total_cofins), "0", "0", fmt_valor(total_cofins),
        fmt_valor(ret_nc_cofins), "0", "0", "0", "0", "0", "0", "0",
    ))

    if base_cst02 > 0:
        linhas.append(montar_linha(
            "M610", "02",
            fmt_valor(base_cst02), fmt_valor(base_cst02), "0", "0", fmt_valor(base_cst02),
            "4", "0", "", fmt_valor(cofins_cst02), "0", "0", "0", "0", fmt_valor(cofins_cst02),
        ))
    if base_cst01 > 0:
        linhas.append(montar_linha(
            "M610", "01",
            fmt_valor(base_cst01), fmt_valor(base_cst01), "0", "0", fmt_valor(base_cst01),
            "7,6", "0", "", fmt_valor(cofins_cst01), "0", "0", "0", "0", fmt_valor(cofins_cst01),
        ))

    linhas.append(f"|M990|{len(linhas) + 1}|")
    return linhas
