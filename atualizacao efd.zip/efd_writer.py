"""
efd_writer.py — Orquestra a montagem final do TXT da EFD Contribuições
"""

from domain.models import NotaFiscal
from builders.bloco0_builder import build_bloco0
from builders.blocoA_builder import build_blocoA
from builders.blocoF_builder import build_blocoF, _agrupar_retencoes
from builders.blocoM_builder import build_blocoM
from builders.bloco1_builder import build_bloco1
from builders.bloco9_builder import build_bloco9
from config.constantes import F100_FIXAS


def gerar_efd(notas: list[NotaFiscal], dt_ini: str, dt_fin: str,
              f100_data: list[dict] = None,
              callback_progresso=None) -> bytes:
    """
    Gera o TXT completo da EFD Contribuições.
    f100_data: lista de F100 lida da planilha de apuração.
               Se None, usa F100_FIXAS de constantes.py como fallback.
    callback_progresso(atual, total, msg): atualiza a UI durante busca de municípios.
    """
    # Usa valores dinâmicos da planilha ou fallback das constantes
    f100 = f100_data if f100_data is not None else F100_FIXAS

    f600s = _agrupar_retencoes(notas)

    todas = []
    todas += build_bloco0(notas, dt_ini, dt_fin, callback_progresso)
    todas += build_blocoA(notas)
    todas += ["|C001|1|", "|C990|2|"]
    todas += ["|D001|1|", "|D990|2|"]
    todas += build_blocoF(notas, f100)
    todas += ["|I001|1|", "|I990|2|"]
    todas += build_blocoM(notas, f600s, f100)
    todas += ["|P001|1|", "|P990|2|"]
    todas += build_bloco1(f100)
    todas += build_bloco9(todas)

    return ("\r\n".join(todas) + "\r\n").encode("latin-1", errors="replace")
