"""
excel_apuracao_reader.py — Lê os valores de receitas financeiras (F100)
da planilha de Apuração PIS/COFINS por mês selecionado.

Estrutura da aba 'Apuração':
  - Linha 4 (idx): cabeçalhos de mês (1.2026, 2.2026, ...)
  - Coluna do mês M = M + 2  (mês 1 → col 3, mês 4 → col 6, etc.)
  - Linha 13: 36114001 FDO NÉX VC (DPV) GAIN
  - Linha 14: 36910001 JUROS S/CRED.TRIBUT
  - Linha 15: 36990099 OUTRAS REC.FINAN EV
"""

import calendar
import pandas as pd


# Mapeamento fixo: linha → (conta, descrição, COD_CTA)
_LINHAS_F100 = [
    (13, "361140001", "FDO NEX VC (DPV) GAIN"),
    (14, "36910001",  "JUROS S/CRED.TRIBUT"),
    (15, "36990099",  "OUTRAS RECEITAS FINANCEIRAS"),
]

_ALIQ_PIS    = 0.0065
_ALIQ_COFINS = 0.04


def ler_f100(caminho: str, mes: int, ano: int) -> list[dict]:
    """
    Lê a planilha de apuração e retorna a lista F100_FIXAS
    para o mês/ano selecionado, no mesmo formato usado em constantes.py.
    """
    df = pd.read_excel(caminho, sheet_name="Apuração", header=None)

    # Coluna do mês: mês 1 → col 3, mês M → col M+2
    col_idx = mes + 2

    # Valida que a coluna existe e tem o cabeçalho certo
    try:
        header = str(df.iloc[4, col_idx])
        esperado = f"{mes}.{ano}"
        if esperado not in header:
            raise ValueError(
                f"Coluna {col_idx} tem cabeçalho '{header}', esperado '{esperado}'. "
                f"Verifique se a planilha de apuração corresponde ao ano correto."
            )
    except IndexError:
        raise ValueError(f"Planilha não tem coluna para o mês {mes}/{ano}.")

    # Último dia do mês para DT_OPER
    ultimo_dia = calendar.monthrange(ano, mes)[1]
    dt_oper = f"{ultimo_dia:02d}{mes:02d}{ano}"

    f100_fixas = []
    for linha_idx, cod_cta, descr in _LINHAS_F100:
        try:
            vl_raw = df.iloc[linha_idx, col_idx]
            if pd.isna(vl_raw) or vl_raw == 0:
                continue
            vl_oper = round(abs(float(vl_raw)), 2)  # valores negativos na planilha
        except Exception:
            continue

        vl_pis    = round(vl_oper * _ALIQ_PIS, 2)
        vl_cofins = round(vl_oper * _ALIQ_COFINS, 2)

        f100_fixas.append({
            "IND_OPER": "1", "IND_ORIG": "", "COD_ITEM": "2018",
            "DT_OPER": dt_oper, "VL_OPER": vl_oper,
            "CST_PIS": "02", "VL_BC_PIS": vl_oper,
            "ALIQ_PIS": _ALIQ_PIS * 100, "VL_PIS": vl_pis,
            "CST_COFINS": "02", "VL_BC_COFINS": vl_oper,
            "ALIQ_COFINS": _ALIQ_COFINS * 100, "VL_COFINS": vl_cofins,
            "NAT_BC_CRED": "", "IND_ORIG_CRED": "",
            "COD_CTA": cod_cta, "COD_CENTRO": "", "COD_PART": "",
        })

    if not f100_fixas:
        raise ValueError(
            f"Nenhum valor de receita financeira encontrado para {mes:02d}/{ano}. "
            f"Verifique a planilha de apuração."
        )

    return f100_fixas


# Teste rápido
if __name__ == "__main__":
    import sys
    f100 = ler_f100(
        '/mnt/user-data/uploads/Apurac_a_o_PIS-COFINS_2026_-_Services_Circ_517.xlsx',
        mes=4, ano=2026
    )
    print(f"F100 para 04/2026: {len(f100)} registros")
    for f in f100:
        print(f"  {f['COD_CTA']:10s}  VL_OPER={f['VL_OPER']:>10.2f}  "
              f"VL_PIS={f['VL_PIS']:>7.2f}  VL_COFINS={f['VL_COFINS']:>7.2f}")

    f100_maio = ler_f100(
        '/mnt/user-data/uploads/Apurac_a_o_PIS-COFINS_2026_-_Services_Circ_517.xlsx',
        mes=5, ano=2026
    )
    print(f"\nF100 para 05/2026: {len(f100_maio)} registros")
    for f in f100_maio:
        print(f"  {f['COD_CTA']:10s}  VL_OPER={f['VL_OPER']:>10.2f}  "
              f"VL_PIS={f['VL_PIS']:>7.2f}  VL_COFINS={f['VL_COFINS']:>7.2f}")
