"""bloco1_builder.py — Monta 1001, 1300, 1700, 1990"""

from config.constantes import (
    RETENCAO_ACUMULADA_PIS, RETENCAO_ACUMULADA_COFINS,
    RETENCAO_PER_APU, F100_FIXAS,
)
from domain.models import NotaFiscal
from domain.formatadores import montar_linha, fmt_valor


def build_bloco1(f100_data: list[dict] = None) -> list[str]:
    f100 = f100_data if f100_data is not None else F100_FIXAS
    linhas = []
    linhas.append("|1001|0|")

    ret_efe_pis    = round(sum(f["VL_PIS"]    for f in f100), 2)
    ret_efe_cofins = round(sum(f["VL_COFINS"] for f in f100), 2)

    vl_apu_pis  = RETENCAO_ACUMULADA_PIS
    linhas.append(montar_linha(
        "1300", "03", RETENCAO_PER_APU,
        fmt_valor(vl_apu_pis), fmt_valor(ret_efe_pis), "0", "0",
        fmt_valor(round(vl_apu_pis - ret_efe_pis, 2)),
    ))

    vl_apu_cofins = RETENCAO_ACUMULADA_COFINS
    linhas.append(montar_linha(
        "1700", "03", RETENCAO_PER_APU,
        fmt_valor(vl_apu_cofins), fmt_valor(ret_efe_cofins), "0", "0",
        fmt_valor(round(vl_apu_cofins - ret_efe_cofins, 2)),
    ))

    linhas.append(f"|1990|{len(linhas) + 1}|")
    return linhas
