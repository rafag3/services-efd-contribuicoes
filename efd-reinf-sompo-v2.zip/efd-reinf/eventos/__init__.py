# Eventos EFD-REINF
from eventos.r4020 import EventoR4020
from eventos.r4010 import EventoR4010
from eventos.r2010 import EventoR2010
