"""
eventos/base.py
Classe base para geradores de eventos EFD-REINF.
"""

import re
from abc import ABC, abstractmethod
from pathlib import Path
from datetime import datetime
from lxml import etree


class EventoBase(ABC):
    CODIGO = ""          # ex: "R-4020"
    NAMESPACE = ""       # namespace XML do evento

    def __init__(self, config: dict, competencia: str):
        """
        config      : dict do config.json
        competencia : string no formato 'AAAAMM' (ex: '202606')
        """
        self.config = config
        self.competencia = competencia  # AAAAMM
        self._seq = 1  # sequencial de eventos gerados

    @property
    def per_apur(self) -> str:
        """Retorna competência no formato AAAA-MM."""
        return f"{self.competencia[:4]}-{self.competencia[4:]}"

    @property
    def tp_amb(self) -> str:
        return "1" if self.config.get("ambiente") == "producao" else "2"

    @property
    def cnpj_contri(self) -> str:
        return re.sub(r"\D", "", self.config.get("cnpj", ""))

    def _gerar_id(self) -> str:
        """
        Gera o atributo 'id' do evento no formato:
        ID + CNPJ(14) + AAAAMM + seq(7)
        """
        seq = str(self._seq).zfill(7)
        self._seq += 1
        return f"ID{self.cnpj_contri}{self.competencia}{seq}"

    def _ide_evento(self, parent, ind_retif="1", nr_recibo=None,
                    ind_apuracao="1", ind_guia="1"):
        ie = etree.SubElement(parent, "ideEvento")
        etree.SubElement(ie, "indRetif").text = ind_retif
        if nr_recibo:
            etree.SubElement(ie, "nrRecibo").text = nr_recibo
        etree.SubElement(ie, "indApuracao").text = ind_apuracao
        etree.SubElement(ie, "perApur").text = self.per_apur
        etree.SubElement(ie, "indGuia").text = ind_guia
        etree.SubElement(ie, "tpAmb").text = self.tp_amb
        etree.SubElement(ie, "procEmi").text = "1"
        etree.SubElement(ie, "verProc").text = "1.0"
        return ie

    def _ide_contri(self, parent):
        ic = etree.SubElement(parent, "ideContri")
        etree.SubElement(ic, "tpInsc").text = "1"
        etree.SubElement(ic, "nrInsc").text = self.cnpj_contri
        return ic

    def _xml_bytes(self, root) -> bytes:
        return etree.tostring(
            root,
            pretty_print=True,
            xml_declaration=True,
            encoding="UTF-8"
        )

    @abstractmethod
    def gerar(self, dados, output_dir: Path) -> Path:
        """Gera o XML do evento e salva em output_dir."""
        ...
