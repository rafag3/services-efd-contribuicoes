"""
eventos/r4020.py
Gerador do evento R-4020 — Pagamentos/Créditos a Beneficiário Pessoa Jurídica.

Fonte de dados: ZFI0066, filtrado por PF/PJ == 'PJ'.

Agrupamento:
  ideEstab  → por CNPJ Filial
    ideBenef  → por CNPJ do beneficiário
      detPag  → por natRend (código natureza do rendimento)
        vrRetIR   = abs(IRRF)
        vrRetCsrf = abs(PIS) + abs(COFINS) + abs(CLL)
        vrRetPrev = abs(INSS)
        vlrBruto  = sum(Valor Bruto)

ATENÇÃO: o campo cnpjContri (ideContri.nrInsc) deve ser o CNPJ
do declarante — confirmar com Rafael/Raquel se é Sompo Seguros
(61383493) ou Sompo Services (46206637).
"""

import json
import re
import pandas as pd
from pathlib import Path
from lxml import etree

from eventos.base import EventoBase

NS = "http://www.reinf.esocial.gov.br/schemas/evtRetPJ/v1_01_00"


def _limpar(valor) -> str:
    return re.sub(r"\D", "", str(valor))


def _fmt(valor: float) -> str:
    """Formata float para string com 2 casas decimais."""
    return f"{abs(valor):.2f}"


class EventoR4020(EventoBase):
    CODIGO = "R-4020"
    NAMESPACE = NS

    def __init__(self, config: dict, competencia: str, codigos_path: Path = None):
        super().__init__(config, competencia)
        self._natRend_map = {}
        self._natRend_padrao = "13001"
        if codigos_path and codigos_path.exists():
            with open(codigos_path, encoding="utf-8") as f:
                cod = json.load(f)
            self._natRend_map = cod.get("darf_irrf_para_natRend", {})
            self._natRend_padrao = cod.get("nat_rend_padrao", "13001")

    def _nat_rend(self, cod_darf: int) -> str:
        return self._natRend_map.get(str(cod_darf), self._natRend_padrao)

    def gerar(self, df_zfi: pd.DataFrame, output_dir: Path) -> Path:
        """
        Gera R-4020 a partir do DataFrame ZFI0066 (já filtrado tipo PJ).
        Retorna o Path do XML gerado (não assinado).
        """
        output_dir = Path(output_dir)
        output_dir.mkdir(parents=True, exist_ok=True)

        # Filtrar apenas PJ
        df = df_zfi[df_zfi["PF/PJ"] == "PJ"].copy()
        if df.empty:
            raise ValueError("Nenhum pagamento PJ encontrado no ZFI0066.")

        # Garantir tipos numéricos
        for col in ["IRRF", "PIS", "COFINS", "CLL", "INSS", "Valor Bruto"]:
            if col in df.columns:
                df[col] = pd.to_numeric(df[col], errors="coerce").fillna(0.0)

        if "Código Retenção IRRF" not in df.columns:
            df["Código Retenção IRRF"] = 0

        df["Código Retenção IRRF"] = (
            pd.to_numeric(df["Código Retenção IRRF"], errors="coerce")
            .fillna(0).astype(int)
        )

        # Mapear natRend
        df["natRend"] = df["Código Retenção IRRF"].apply(self._nat_rend)

        # ── Construir XML ──────────────────────────────────────
        evt_id = self._gerar_id()

        root = etree.Element("Reinf", nsmap={None: NS})
        evt = etree.SubElement(root, "evtRetPJ")
        evt.set("id", evt_id)

        self._ide_evento(evt)
        self._ide_contri(evt)

        # Agrupar por CNPJ Filial → CNPJ Beneficiário → natRend
        for cnpj_filial, grp_filial in df.groupby("CNPJ Filial"):
            ide_estab = etree.SubElement(evt, "ideEstab")
            etree.SubElement(ide_estab, "tpInsc").text = "1"
            etree.SubElement(ide_estab, "nrInsc").text = _limpar(cnpj_filial)

            pagamentos_estab = etree.SubElement(ide_estab, "pagamentos")

            for cnpj_benef, grp_benef in grp_filial.groupby("CNPJ/CPF"):
                ide_benef = etree.SubElement(pagamentos_estab, "ideBenef")
                etree.SubElement(ide_benef, "cnpjBenef").text = _limpar(cnpj_benef)

                pag_benef = etree.SubElement(ide_benef, "pagamentos")

                for nat_rend, grp_nat in grp_benef.groupby("natRend"):
                    vlr_bruto = grp_nat["Valor Bruto"].sum()
                    vr_irrf   = grp_nat["IRRF"].abs().sum()
                    vr_csrf   = (
                        grp_nat["PIS"].abs().sum() +
                        grp_nat["COFINS"].abs().sum() +
                        grp_nat["CLL"].abs().sum()
                    )
                    vr_prev   = grp_nat["INSS"].abs().sum()

                    det_pag = etree.SubElement(pag_benef, "detPag")
                    etree.SubElement(det_pag, "natRend").text = str(nat_rend)
                    etree.SubElement(det_pag, "vlrBruto").text = _fmt(vlr_bruto)

                    retencoes = etree.SubElement(det_pag, "retencoes")
                    if vr_irrf > 0:
                        etree.SubElement(retencoes, "vrRetIR").text = _fmt(vr_irrf)
                    if vr_prev > 0:
                        etree.SubElement(retencoes, "vrRetPrev").text = _fmt(vr_prev)
                    if vr_csrf > 0:
                        etree.SubElement(retencoes, "vrRetCsrf").text = _fmt(vr_csrf)

        # Salvar XML
        output_path = output_dir / f"R-4020_{self.competencia}.xml"
        with open(output_path, "wb") as f:
            f.write(self._xml_bytes(root))

        return output_path
