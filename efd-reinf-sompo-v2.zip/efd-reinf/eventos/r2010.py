"""
eventos/r2010.py
Gerador do evento R-2010 — Retenção Contribuição Previdenciária — Serviços Tomados.

Fonte de dados: planilha 21131302 (INSS Retido de Terceiros), tipo CD.

Agrupamento:
  ideEstab → por CNPJ da filial (CNPJ-Filial da planilha de conta)
    nfTom → por documento (Nº doc. Cont. FI + item)
      vlrBruto    = Base imposto MI (abs)
      vlrRetencao = Montante MI (abs)
"""

import re
import pandas as pd
from pathlib import Path
from lxml import etree

from eventos.base import EventoBase

NS = "http://www.reinf.esocial.gov.br/schemas/evtServTomados/v2_01_02"


def _limpar(valor) -> str:
    return re.sub(r"\D", "", str(valor))


def _fmt(valor: float) -> str:
    return f"{abs(valor):.2f}"


class EventoR2010(EventoBase):
    CODIGO = "R-2010"
    NAMESPACE = NS

    def gerar(self, df_inss: pd.DataFrame, output_dir: Path) -> Path:
        output_dir = Path(output_dir)
        output_dir.mkdir(parents=True, exist_ok=True)

        df = df_inss.copy()
        if df.empty:
            raise ValueError("Nenhum dado INSS encontrado na planilha 21131302.")

        for col in ["Montante MI", "Base imposto MI"]:
            if col in df.columns:
                df[col] = pd.to_numeric(df[col], errors="coerce").fillna(0.0)

        # Filtrar só linhas com retenção real
        df = df[df["Montante MI"].abs() > 0].copy()

        if df.empty:
            raise ValueError("Nenhuma linha com Montante MI != 0 encontrada na planilha INSS.")

        evt_id = self._gerar_id()

        root = etree.Element("Reinf", nsmap={None: NS})
        evt = etree.SubElement(root, "evtServTomados")
        evt.set("id", evt_id)

        # ideEvento sem indGuia (não aplicável ao R-2010)
        ie = etree.SubElement(evt, "ideEvento")
        etree.SubElement(ie, "indRetif").text = "1"
        etree.SubElement(ie, "perApur").text = self.per_apur
        etree.SubElement(ie, "tpAmb").text = self.tp_amb
        etree.SubElement(ie, "procEmi").text = "1"
        etree.SubElement(ie, "verProc").text = "1.0"

        self._ide_contri(evt)

        # Agrupar por CNPJ Filial
        col_filial = "CNPJ - Filial" if "CNPJ - Filial" in df.columns else None

        if col_filial:
            df["_cnpj_filial"] = df[col_filial].apply(
                lambda x: re.sub(r"\D", "", str(x)) if pd.notna(x) else self.cnpj_contri
            )
        else:
            df["_cnpj_filial"] = self.cnpj_contri

        for cnpj_filial, grp in df.groupby("_cnpj_filial"):
            ide_estab = etree.SubElement(evt, "ideEstab")
            etree.SubElement(ide_estab, "tpInsc").text = "1"
            etree.SubElement(ide_estab, "nrInsc").text = cnpj_filial

            # Agrupar por prestador (CPF/CNPJ)
            col_prestador = "CPF/CNPJ" if "CPF/CNPJ" in grp.columns else None

            if col_prestador:
                for cnpj_prest, grp_p in grp.groupby(col_prestador):
                    pf_pj = str(grp_p["PF/PJ"].iloc[0]).upper() if "PF/PJ" in grp_p.columns else "PJ"
                    cnpj_limpo = re.sub(r"\D", "", str(cnpj_prest))

                    ide_tpServico = etree.SubElement(ide_estab, "ideTomadorServico")

                    if pf_pj == "PJ":
                        etree.SubElement(ide_tpServico, "tpInscPrestador").text = "1"
                        etree.SubElement(ide_tpServico, "nrInscPrestador").text = cnpj_limpo
                    else:
                        etree.SubElement(ide_tpServico, "tpInscPrestador").text = "2"
                        etree.SubElement(ide_tpServico, "nrInscPrestador").text = cnpj_limpo

                    for _, row in grp_p.iterrows():
                        nf_tom = etree.SubElement(ide_tpServico, "nfTom")

                        nr_doc = str(row.get("Nº doc. Cont. FI", "")).strip()
                        nr_nf  = str(row.get("Número NF", "")).strip()
                        etree.SubElement(nf_tom, "serie").text = "0"
                        etree.SubElement(nf_tom, "nrDocto").text = nr_nf if nr_nf else nr_doc

                        dt = row.get("Data lançamento")
                        if pd.notna(dt):
                            etree.SubElement(nf_tom, "dtEmissaoNF").text = pd.Timestamp(dt).strftime("%Y-%m-%d")

                        vlr_bruto = abs(float(row.get("Base imposto MI", 0) or 0))
                        vlr_ret   = abs(float(row.get("Montante MI", 0) or 0))

                        etree.SubElement(nf_tom, "vlrBruto").text = f"{vlr_bruto:.2f}"
                        etree.SubElement(nf_tom, "vlrRetencao").text = f"{vlr_ret:.2f}"

        output_path = output_dir / f"R-2010_{self.competencia}.xml"
        with open(output_path, "wb") as f:
            f.write(self._xml_bytes(root))

        return output_path
