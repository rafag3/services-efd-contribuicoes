"""
main.py — EFD-REINF | Sompo Seguros
Interface gráfica para geração, assinatura e envio de eventos EFD-REINF.
"""

import os, sys, json, threading, tkinter as tk
from tkinter import ttk, filedialog, messagebox
from pathlib import Path
from datetime import datetime

if getattr(sys, "frozen", False):
    BASE_DIR = Path(sys.executable).parent
else:
    BASE_DIR = Path(__file__).resolve().parent

sys.path.insert(0, str(BASE_DIR))

from core.config_manager   import carregar_config, get_cert_path
from core.assinar          import assinar_xml
from core.enviar           import enviar_lote
from core.leitura_planilhas import PlanilhasMes
from core.batimento        import executar_batimento

# ── Paleta Sompo ─────────────────────────────────────────────
C_RED        = "#C41230"
C_RED_DARK   = "#8B0C1E"
C_RED_HOVER  = "#E01535"
C_GRAY_DARK  = "#2B2B2B"
C_GRAY_MID   = "#3C3C3C"
C_GRAY_PANEL = "#F2F2F2"
C_GRAY_LINE  = "#DCDCDC"
C_WHITE      = "#FFFFFF"
C_TEXT_DARK  = "#1A1A1A"
C_TEXT_MID   = "#555555"
C_TEXT_LIGHT = "#888888"
C_LOG_BG     = "#1C1C1C"
C_LOG_FG     = "#E8E8E8"
C_LOG_GREEN  = "#4EC94E"
C_LOG_YELLOW = "#F0C060"
C_LOG_RED    = "#FF6060"

FONT_LABEL  = ("Segoe UI", 9)
FONT_SMALL  = ("Segoe UI", 8)
FONT_MONO   = ("Consolas", 9)
FONT_HEADER = ("Segoe UI", 14, "bold")
FONT_SUB    = ("Segoe UI", 8)


# ── Botão customizado ─────────────────────────────────────────
class SompoButton(tk.Canvas):
    def __init__(self, parent, text, command, width=160, height=38,
                 bg=C_RED, bg_hover=C_RED_HOVER, fg=C_WHITE,
                 icon="", disabled=False, **kwargs):
        super().__init__(parent, width=width, height=height,
                         bg=parent.cget("bg"), highlightthickness=0,
                         cursor="hand2" if not disabled else "arrow", **kwargs)
        self._text     = text
        self._icon     = icon
        self._command  = command
        self._bg       = bg
        self._bg_hover = bg_hover
        self._fg       = fg
        self._btn_w    = width
        self._btn_h    = height
        self._disabled = disabled

        self.after_idle(lambda: self._draw(self._bg))
        self.bind("<Enter>",    self._on_enter)
        self.bind("<Leave>",    self._on_leave)
        self.bind("<Button-1>", self._on_click)

    def _draw(self, color):
        try:
            self.delete("all")
        except tk.TclError:
            return
        r = 5
        x1, y1, x2, y2 = 1, 1, self._btn_w - 1, self._btn_h - 1
        self.create_arc(x1, y1, x1+r*2, y1+r*2, start=90,  extent=90,  fill=color, outline=color)
        self.create_arc(x2-r*2, y1, x2, y1+r*2, start=0,   extent=90,  fill=color, outline=color)
        self.create_arc(x1, y2-r*2, x1+r*2, y2, start=180, extent=90,  fill=color, outline=color)
        self.create_arc(x2-r*2, y2-r*2, x2, y2, start=270, extent=90,  fill=color, outline=color)
        self.create_rectangle(x1+r, y1, x2-r, y2, fill=color, outline=color)
        self.create_rectangle(x1, y1+r, x2, y2-r, fill=color, outline=color)
        label = f"{self._icon}  {self._text}" if self._icon else self._text
        cor_txt = self._fg if not self._disabled else "#999999"
        self.create_text(self._btn_w//2, self._btn_h//2, text=label,
                         fill=cor_txt, font=FONT_LABEL, anchor="center")

    def _on_enter(self, e):
        if not self._disabled: self._draw(self._bg_hover)
    def _on_leave(self, e):
        if not self._disabled: self._draw(self._bg)
    def _on_click(self, e):
        if not self._disabled and self._command: self._command()
    def set_disabled(self, val):
        self._disabled = val
        self.configure(cursor="arrow" if val else "hand2")
        self._draw(self._bg)


# ── App principal ─────────────────────────────────────────────
class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("EFD-REINF — Sompo Seguros")
        self.resizable(False, False)
        self.configure(bg=C_GRAY_PANEL)
        self._center(1060, 700)
        self._set_icon()

        self.config_data          = {}
        self.xml_path             = tk.StringVar()
        self.pasta_planilhas      = tk.StringVar()
        self.competencia_var      = tk.StringVar(value=datetime.now().strftime("%Y%m"))
        self.xml_assinado_path    = None
        self._planilhas_mes       = None
        self._xmls_gerados        = []

        self._build_ui()
        self._carregar_config_auto()

    def _center(self, w, h):
        self.update_idletasks()
        sw, sh = self.winfo_screenwidth(), self.winfo_screenheight()
        self.geometry(f"{w}x{h}+{(sw-w)//2}+{(sh-h)//2}")

    def _set_icon(self):
        ico = BASE_DIR / "assets" / "icon.ico"
        if ico.exists():
            try: self.iconbitmap(str(ico))
            except: pass

    # ── Layout ────────────────────────────────────────────────
    def _build_ui(self):
        self._build_header()
        body = tk.Frame(self, bg=C_GRAY_PANEL)
        body.pack(fill="both", expand=True, padx=16, pady=(0, 12))

        left  = tk.Frame(body, bg=C_GRAY_PANEL, width=430)
        right = tk.Frame(body, bg=C_GRAY_PANEL)
        left.pack(side="left", fill="both", padx=(0, 10))
        right.pack(side="left", fill="both", expand=True)
        left.pack_propagate(False)

        self._build_config_panel(left)
        self._build_planilhas_panel(left)
        self._build_xml_panel(left)
        self._build_actions(left)
        self._build_log(right)
        self._build_status_bar()

    def _build_header(self):
        hdr = tk.Frame(self, bg=C_RED, height=68)
        hdr.pack(fill="x")
        hdr.pack_propagate(False)

        lf = tk.Frame(hdr, bg=C_RED)
        lf.pack(side="left", padx=20, pady=10)

        logo_path = BASE_DIR / "assets" / "logo.png"
        if logo_path.exists():
            try:
                from PIL import Image, ImageTk
                img = Image.open(str(logo_path)).resize((120, 40), Image.LANCZOS)
                self._logo_img = ImageTk.PhotoImage(img)
                tk.Label(lf, image=self._logo_img, bg=C_RED).pack()
            except:
                self._logo_fallback(lf)
        else:
            self._logo_fallback(lf)

        tk.Frame(hdr, bg="#E03050", width=1).pack(side="left", fill="y", padx=14, pady=12)

        tf = tk.Frame(hdr, bg=C_RED)
        tf.pack(side="left", pady=10)
        tk.Label(tf, text="EFD-REINF", font=FONT_HEADER, fg=C_WHITE, bg=C_RED).pack(anchor="w")
        tk.Label(tf, text="Geração · Assinatura · Envio de Eventos",
                 font=FONT_SUB, fg="#FFAAAA", bg=C_RED).pack(anchor="w")

        self._badge_var = tk.StringVar(value="● PROD. RESTRITA")
        self._badge_lbl = tk.Label(hdr, textvariable=self._badge_var,
                                   font=("Segoe UI", 8, "bold"),
                                   fg="#FFE08A", bg=C_RED_DARK, padx=10, pady=4)
        self._badge_lbl.pack(side="right", padx=18, pady=20)

    def _logo_fallback(self, parent):
        c = tk.Canvas(parent, width=100, height=42, bg=C_RED, highlightthickness=0)
        c.pack()
        c.create_rectangle(0, 8, 32, 40, fill=C_RED_DARK, outline="")
        c.create_text(16, 24, text="S", font=("Segoe UI", 14, "bold"), fill=C_WHITE)
        c.create_text(68, 22, text="SOMPO", font=("Segoe UI", 12, "bold"), fill=C_WHITE)
        c.create_text(68, 36, text="SEGUROS", font=("Segoe UI", 7), fill="#FFCCCC")

    def _card(self, parent, title):
        outer = tk.Frame(parent, bg=C_GRAY_PANEL)
        outer.pack(fill="x", pady=(0, 8))
        hdr = tk.Frame(outer, bg=C_RED, height=26)
        hdr.pack(fill="x")
        hdr.pack_propagate(False)
        tk.Label(hdr, text=f"  {title}", font=("Segoe UI", 9, "bold"),
                 fg=C_WHITE, bg=C_RED, anchor="w").pack(fill="x", pady=4)
        inner = tk.Frame(outer, bg=C_WHITE, padx=12, pady=8,
                         highlightbackground=C_GRAY_LINE, highlightthickness=1)
        inner.pack(fill="x")
        return inner

    def _build_config_panel(self, parent):
        card = self._card(parent, "⚙  Configuração")
        self._cnpj_var  = tk.StringVar()
        self._amb_var   = tk.StringVar()
        self._cert_var  = tk.StringVar()
        self._razao_var = tk.StringVar()
        for lbl, var in [("CNPJ", self._cnpj_var), ("Razão Social", self._razao_var),
                          ("Ambiente", self._amb_var), ("Certificado", self._cert_var)]:
            row = tk.Frame(card, bg=C_WHITE)
            row.pack(fill="x", pady=1)
            tk.Label(row, text=f"{lbl}:", font=FONT_SMALL, fg=C_TEXT_MID,
                     bg=C_WHITE, width=12, anchor="w").pack(side="left")
            tk.Label(row, textvariable=var, font=FONT_SMALL, fg=C_TEXT_DARK,
                     bg=C_WHITE, anchor="w", wraplength=260).pack(side="left", fill="x", expand=True)
        br = tk.Frame(card, bg=C_WHITE)
        br.pack(fill="x", pady=(6,0))
        SompoButton(br, "Recarregar", self._carregar_config_auto,
                    width=110, height=28, bg=C_GRAY_MID, bg_hover="#555555").pack(side="left", padx=(0,6))
        SompoButton(br, "Editar config.json", self._abrir_config,
                    width=150, height=28, bg=C_GRAY_MID, bg_hover="#555555").pack(side="left")

    def _build_planilhas_panel(self, parent):
        card = self._card(parent, "📁  Planilhas SAP")

        # Pasta
        row1 = tk.Frame(card, bg=C_WHITE)
        row1.pack(fill="x", pady=2)
        tk.Label(row1, text="Pasta:", font=FONT_SMALL, fg=C_TEXT_MID,
                 bg=C_WHITE, width=10, anchor="w").pack(side="left")
        tk.Entry(row1, textvariable=self.pasta_planilhas, font=FONT_SMALL,
                 fg=C_TEXT_DARK, bg="#F9F9F9", relief="solid", bd=1,
                 width=26).pack(side="left", fill="x", expand=True, ipady=3)
        SompoButton(row1, "...", self._browse_pasta,
                    width=32, height=26, bg=C_GRAY_MID, bg_hover="#555555").pack(side="left", padx=(4,0))

        # Competência
        row2 = tk.Frame(card, bg=C_WHITE)
        row2.pack(fill="x", pady=2)
        tk.Label(row2, text="Competência:", font=FONT_SMALL, fg=C_TEXT_MID,
                 bg=C_WHITE, width=10, anchor="w").pack(side="left")
        tk.Entry(row2, textvariable=self.competencia_var, font=FONT_SMALL,
                 fg=C_TEXT_DARK, bg="#F9F9F9", relief="solid", bd=1,
                 width=10).pack(side="left", ipady=3)
        tk.Label(row2, text="(AAAAMM)", font=FONT_SMALL,
                 fg=C_TEXT_LIGHT, bg=C_WHITE).pack(side="left", padx=6)

        # Botões
        br = tk.Frame(card, bg=C_WHITE)
        br.pack(fill="x", pady=(6,0))
        self._btn_analisar = SompoButton(br, "Analisar Planilhas", self._run_analisar,
                                         width=155, height=30, bg=C_GRAY_MID, bg_hover="#555555",
                                         icon="🔍")
        self._btn_analisar.pack(side="left", padx=(0,6))
        self._btn_gerar = SompoButton(br, "Gerar XMLs", self._run_gerar,
                                      width=140, height=30, icon="⚙")
        self._btn_gerar.pack(side="left")

        # Status planilhas
        self._plan_status = tk.Label(card, text="Nenhuma pasta selecionada.",
                                     font=FONT_SMALL, fg=C_TEXT_LIGHT, bg=C_WHITE, anchor="w")
        self._plan_status.pack(fill="x", pady=(4,0))

    def _build_xml_panel(self, parent):
        card = self._card(parent, "📄  XML para Assinar/Enviar")
        row = tk.Frame(card, bg=C_WHITE)
        row.pack(fill="x", pady=2)
        tk.Entry(row, textvariable=self.xml_path, font=FONT_SMALL,
                 fg=C_TEXT_DARK, bg="#F9F9F9", relief="solid", bd=1,
                 width=34).pack(side="left", fill="x", expand=True, ipady=4)
        SompoButton(row, "...", self._browse_xml,
                    width=32, height=28, bg=C_GRAY_MID, bg_hover="#555555").pack(side="left", padx=(4,0))
        self._xml_info = tk.Label(card, text="Selecione um XML ou gere acima.",
                                  font=FONT_SMALL, fg=C_TEXT_LIGHT, bg=C_WHITE, anchor="w")
        self._xml_info.pack(fill="x", pady=(4,0))

        # Lista de XMLs gerados
        self._xmls_frame = tk.Frame(card, bg=C_WHITE)
        self._xmls_frame.pack(fill="x", pady=(4,0))

    def _build_actions(self, parent):
        card = self._card(parent, "🚀  Ações")
        self._btn_assinar = SompoButton(card, "Assinar XML", self._run_assinar,
                                        width=165, height=36, icon="✍")
        self._btn_assinar.pack(side="left", padx=(0,8))
        self._btn_enviar = SompoButton(card, "Enviar à RF", self._run_enviar,
                                       width=165, height=36, icon="📤",
                                       bg=C_GRAY_MID, bg_hover="#555555")
        self._btn_enviar.pack(side="left")

    def _build_log(self, parent):
        hdr = tk.Frame(parent, bg=C_RED, height=26)
        hdr.pack(fill="x")
        hdr.pack_propagate(False)
        tk.Label(hdr, text="  📋  Log de Execução", font=("Segoe UI", 9, "bold"),
                 fg=C_WHITE, bg=C_RED, anchor="w").pack(fill="x", pady=4)

        lf = tk.Frame(parent, bg=C_LOG_BG)
        lf.pack(fill="both", expand=True)
        self._log = tk.Text(lf, bg=C_LOG_BG, fg=C_LOG_FG, font=FONT_MONO,
                            relief="flat", bd=0, state="disabled", wrap="word",
                            selectbackground=C_RED_DARK, padx=10, pady=8)
        sb = tk.Scrollbar(lf, command=self._log.yview, bg=C_GRAY_MID,
                          troughcolor=C_LOG_BG, width=10)
        self._log.configure(yscrollcommand=sb.set)
        sb.pack(side="right", fill="y")
        self._log.pack(fill="both", expand=True)
        self._log.tag_config("ok",    foreground=C_LOG_GREEN)
        self._log.tag_config("warn",  foreground=C_LOG_YELLOW)
        self._log.tag_config("error", foreground=C_LOG_RED)
        self._log.tag_config("info",  foreground=C_LOG_FG)
        self._log.tag_config("ts",    foreground="#666666")

        br = tk.Frame(parent, bg=C_GRAY_PANEL)
        br.pack(fill="x", pady=(6,0))
        SompoButton(br, "Limpar Log", self._limpar_log,
                    width=110, height=28, bg=C_GRAY_MID, bg_hover="#555555").pack(side="right")

    def _build_status_bar(self):
        bar = tk.Frame(self, bg=C_GRAY_DARK, height=24)
        bar.pack(fill="x", side="bottom")
        bar.pack_propagate(False)
        self._status_var = tk.StringVar(value="Pronto.")
        tk.Label(bar, textvariable=self._status_var, font=FONT_SMALL,
                 fg="#AAAAAA", bg=C_GRAY_DARK, anchor="w", padx=12).pack(side="left", fill="y")
        tk.Label(bar, text="Sompo Seguros  •  Fiscal",
                 font=FONT_SMALL, fg="#666666", bg=C_GRAY_DARK, padx=12).pack(side="right", fill="y")

    # ── Helpers de log ────────────────────────────────────────
    def _log_write(self, msg: str):
        def _do():
            self._log.configure(state="normal")
            ts = datetime.now().strftime("%H:%M:%S")
            self._log.insert("end", f"[{ts}]  ", "ts")
            if   msg.startswith(("✅","🎉")): tag = "ok"
            elif msg.startswith(("⚠️","📬","⚠")): tag = "warn"
            elif msg.startswith("❌"):         tag = "error"
            else:                              tag = "info"
            self._log.insert("end", msg + "\n", tag)
            self._log.configure(state="disabled")
            self._log.see("end")
        self.after(0, _do)

    def _limpar_log(self):
        self._log.configure(state="normal")
        self._log.delete("1.0", "end")
        self._log.configure(state="disabled")

    def _set_status(self, msg):
        self.after(0, lambda: self._status_var.set(msg))

    def _set_plan_status(self, msg, cor=C_TEXT_MID):
        self.after(0, lambda: self._plan_status.configure(text=msg, fg=cor))

    # ── Config ────────────────────────────────────────────────
    def _carregar_config_auto(self):
        try:
            self.config_data = carregar_config(str(BASE_DIR / "config" / "config.json"))
            self._cnpj_var.set(self.config_data.get("cnpj", "—"))
            self._razao_var.set(self.config_data.get("razao_social", "—"))
            self._amb_var.set(self.config_data.get("ambiente", "—"))
            self._cert_var.set(Path(self.config_data.get("certificado","")).name)
            amb = self.config_data.get("ambiente","")
            if amb == "producao":
                self._badge_var.set("● PRODUÇÃO")
                self._badge_lbl.configure(fg="#FF8080")
            else:
                self._badge_var.set("● PROD. RESTRITA")
                self._badge_lbl.configure(fg="#FFE08A")
            self._log_write("✅ Configuração carregada.")
        except Exception as e:
            self._log_write(f"❌ Erro ao carregar config: {e}")
            messagebox.showerror("Erro de Configuração", str(e))


    def _abrir_config(self):
        """Abre config.json no editor padrão do sistema."""
        import subprocess, platform
        cfg = BASE_DIR / "config" / "config.json"
        try:
            if platform.system() == "Windows":
                os.startfile(str(cfg))
            else:
                subprocess.Popen(["xdg-open", str(cfg)])
            self._log_write("✏  config.json aberto. Salve e clique em Recarregar.")
        except Exception as e:
            messagebox.showerror("Erro", f"Não foi possível abrir o arquivo:\n{e}")
    # ── Planilhas ─────────────────────────────────────────────
    def _browse_pasta(self):
        pasta = filedialog.askdirectory(title="Selecionar pasta com planilhas SAP")
        if pasta:
            self.pasta_planilhas.set(pasta)
            self._log_write(f"📁 Pasta: {pasta}")

    def _run_analisar(self):
        pasta = self.pasta_planilhas.get().strip()
        comp  = self.competencia_var.get().strip()
        if not pasta:
            messagebox.showwarning("Atenção", "Selecione a pasta com as planilhas SAP.")
            return
        if len(comp) != 6 or not comp.isdigit():
            messagebox.showwarning("Atenção", "Competência deve estar no formato AAAAMM (ex: 202606).")
            return

        self._btn_analisar.set_disabled(True)
        self._btn_gerar.set_disabled(True)
        self._log_write("─" * 50)
        self._log_write(f"🔍 Analisando planilhas — competência {comp[:4]}-{comp[4:]}")

        def _tarefa():
            try:
                pm = PlanilhasMes(Path(pasta), comp)
                pm.carregar(log=self._log_write)

                if not pm.valido:
                    for e in pm._erros:
                        self._log_write(f"❌ {e}")
                    self._set_plan_status("Erro no carregamento.", C_LOG_RED)
                    return

                self._planilhas_mes = pm
                resumo = pm.resumo()

                # Batimento
                rel = executar_batimento(
                    pm.zfi,
                    df_irrf=pm.irrf,
                    df_inss=pm.inss,
                    df_pisc=pm.pisc,
                )
                for linha in rel.linhas_log():
                    self._log_write(linha)

                cor = C_LOG_GREEN if rel.aprovado else C_LOG_YELLOW
                status = (f"✅ Pronto — {resumo.get('zfi_pj',0)} PJ · "
                          f"{resumo.get('zfi_pf',0)} PF")
                self._set_plan_status(status, cor)
                self._set_status("Análise concluída.")

                if not rel.aprovado:
                    self.after(0, lambda: messagebox.showwarning(
                        "Batimento com diferenças",
                        "Foram encontradas diferenças entre ZFI0066 e as planilhas de conta.\n"
                        "Verifique o log antes de gerar os XMLs."
                    ))
            except Exception as e:
                self._log_write(f"❌ Erro na análise: {e}")
                self._set_plan_status("Erro.", C_LOG_RED)
            finally:
                self.after(0, lambda: self._btn_analisar.set_disabled(False))
                self.after(0, lambda: self._btn_gerar.set_disabled(False))

        threading.Thread(target=_tarefa, daemon=True).start()

    def _run_gerar(self):
        if not self._planilhas_mes or not self._planilhas_mes.valido:
            messagebox.showwarning("Atenção", "Analise as planilhas primeiro.")
            return
        if not self.config_data:
            messagebox.showwarning("Atenção", "Carregue a configuração primeiro.")
            return

        self._btn_gerar.set_disabled(True)
        self._btn_analisar.set_disabled(True)
        self._log_write("─" * 50)
        self._log_write("⚙  Gerando XMLs dos eventos...")

        def _tarefa():
            try:
                from eventos.r4020 import EventoR4020
                from eventos.r4010 import EventoR4010
                from eventos.r2010 import EventoR2010

                pm      = self._planilhas_mes
                comp    = pm.competencia
                cfg     = self.config_data
                codigos = BASE_DIR / "config" / "codigos.json"
                saida   = BASE_DIR / "xmls"
                gerados = []

                # R-4020 (PJ)
                if pm.zfi is not None and (pm.zfi["PF/PJ"] == "PJ").any():
                    try:
                        evt = EventoR4020(cfg, comp, codigos)
                        path = evt.gerar(pm.zfi, saida)
                        gerados.append(path)
                        self._log_write(f"✅ R-4020 gerado: {path.name}")
                    except Exception as e:
                        self._log_write(f"⚠️  R-4020: {e}")

                # R-4010 (PF)
                if pm.zfi is not None and (pm.zfi["PF/PJ"] == "PF").any():
                    try:
                        evt = EventoR4010(cfg, comp, codigos)
                        path = evt.gerar(pm.zfi, saida)
                        gerados.append(path)
                        self._log_write(f"✅ R-4010 gerado: {path.name}")
                    except Exception as e:
                        self._log_write(f"⚠️  R-4010: {e}")

                # R-2010 (INSS)
                if pm.inss is not None and not pm.inss.empty:
                    try:
                        evt = EventoR2010(cfg, comp)
                        path = evt.gerar(pm.inss, saida)
                        gerados.append(path)
                        self._log_write(f"✅ R-2010 gerado: {path.name}")
                    except Exception as e:
                        self._log_write(f"⚠️  R-2010: {e}")

                self._xmls_gerados = gerados
                self.after(0, lambda: self._atualizar_lista_xmls(gerados))

                if gerados:
                    self._log_write(f"🎉 {len(gerados)} XML(s) gerado(s) em xmls/")
                    self._log_write("   Selecione um XML abaixo → Assinar → Enviar.")
                    self._set_status(f"{len(gerados)} XML(s) gerado(s).")
                else:
                    self._log_write("⚠️  Nenhum XML gerado. Verifique os erros acima.")

            except Exception as e:
                self._log_write(f"❌ Erro ao gerar XMLs: {e}")
            finally:
                self.after(0, lambda: self._btn_gerar.set_disabled(False))
                self.after(0, lambda: self._btn_analisar.set_disabled(False))

        threading.Thread(target=_tarefa, daemon=True).start()

    def _atualizar_lista_xmls(self, gerados: list):
        for w in self._xmls_frame.winfo_children():
            w.destroy()
        if not gerados:
            return
        tk.Label(self._xmls_frame, text="XMLs gerados — clique para selecionar:",
                 font=FONT_SMALL, fg=C_TEXT_MID, bg=C_WHITE).pack(anchor="w")
        for p in gerados:
            btn = tk.Button(
                self._xmls_frame, text=f"  📄 {p.name}",
                font=FONT_SMALL, fg=C_RED, bg=C_WHITE,
                relief="flat", cursor="hand2", anchor="w",
                command=lambda pp=p: self._selecionar_xml_gerado(pp)
            )
            btn.pack(fill="x")

    def _selecionar_xml_gerado(self, path: Path):
        self.xml_path.set(str(path))
        self.xml_assinado_path = None
        sz = path.stat().st_size
        self._xml_info.configure(text=f"📄 {path.name}  ({sz:,} bytes)", fg=C_TEXT_DARK)
        self._log_write(f"📄 Selecionado para assinatura: {path.name}")

    # ── XML browse ────────────────────────────────────────────
    def _browse_xml(self):
        path = filedialog.askopenfilename(
            title="Selecionar XML EFD-REINF",
            initialdir=BASE_DIR / "xmls",
            filetypes=[("XML", "*.xml"), ("Todos", "*.*")]
        )
        if path:
            self.xml_path.set(path)
            self.xml_assinado_path = None
            sz = os.path.getsize(path)
            self._xml_info.configure(text=f"📄 {Path(path).name}  ({sz:,} bytes)", fg=C_TEXT_DARK)
            self._log_write(f"📄 XML selecionado: {Path(path).name}")

    # ── Assinar ───────────────────────────────────────────────
    def _run_assinar(self):
        if not self.config_data:
            messagebox.showwarning("Atenção", "Carregue a configuração primeiro.")
            return
        xml_str = self.xml_path.get().strip()
        if not xml_str:
            messagebox.showwarning("Atenção", "Selecione um XML para assinar.")
            return

        self._btn_assinar.set_disabled(True)
        self._btn_enviar.set_disabled(True)
        self._log_write("─" * 50)
        self._log_write("✍  Assinando XML (XMLDSig)...")

        def _tarefa():
            try:
                output = assinar_xml(
                    Path(xml_str),
                    get_cert_path(self.config_data),
                    self.config_data["senha_certificado"]
                )
                self.xml_assinado_path = output
                self._log_write(f"✅ XML assinado: {output.name}")
                self._log_write("🎉 Pronto para envio.")
                self._set_status("Assinatura concluída.")
                self.after(0, lambda: messagebox.showinfo("Sucesso",
                    f"XML assinado com sucesso!\n\n{output.name}"))
            except Exception as e:
                self._log_write(f"❌ Falha na assinatura: {e}")
                self.after(0, lambda: messagebox.showerror("Erro", str(e)))
            finally:
                self.after(0, lambda: self._btn_assinar.set_disabled(False))
                self.after(0, lambda: self._btn_enviar.set_disabled(False))

        threading.Thread(target=_tarefa, daemon=True).start()

    # ── Enviar ────────────────────────────────────────────────
    def _run_enviar(self):
        if not self.config_data:
            messagebox.showwarning("Atenção", "Carregue a configuração primeiro.")
            return
        if not self.xml_assinado_path or not self.xml_assinado_path.exists():
            messagebox.showwarning("Atenção", "Assine o XML antes de enviar.")
            return

        amb = self.config_data.get("ambiente", "")
        if amb == "producao":
            if not messagebox.askyesno("Confirmar — PRODUÇÃO",
                "⚠️  Você está enviando para PRODUÇÃO da Receita Federal.\nDeseja continuar?"):
                return

        self._btn_assinar.set_disabled(True)
        self._btn_enviar.set_disabled(True)
        self._log_write("─" * 50)
        self._log_write(f"📤 Enviando — ambiente: {amb.upper()}")

        def _tarefa():
            try:
                resp = enviar_lote(
                    self.xml_assinado_path,
                    get_cert_path(self.config_data),
                    self.config_data["senha_certificado"],
                    amb,
                    output_dir=BASE_DIR / "xmls",
                    log_callback=self._log_write
                )
                self._log_write(f"🎉 Envio OK! Resposta: {resp.name}")
                self._set_status("Envio concluído.")
                self.after(0, lambda: messagebox.showinfo("Enviado",
                    f"Lote enviado!\nResposta salva em:\n{resp.name}"))
            except Exception as e:
                self._log_write(f"❌ Falha no envio: {e}")
                self.after(0, lambda: messagebox.showerror("Erro de Envio", str(e)))
            finally:
                self.after(0, lambda: self._btn_assinar.set_disabled(False))
                self.after(0, lambda: self._btn_enviar.set_disabled(False))

        threading.Thread(target=_tarefa, daemon=True).start()


if __name__ == "__main__":
    App().mainloop()
