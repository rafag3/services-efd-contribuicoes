"""
core/batimento.py
Cruza os valores do ZFI0066 com as planilhas de conta SAP.
Gera relatório de diferenças antes de gerar os XMLs.
"""

import pandas as pd
from dataclasses import dataclass, field
from typing import Optional


@dataclass
class ResultadoBatimento:
    tributo: str
    valor_zfi: float
    valor_conta: float
    diferenca: float
    ok: bool
    detalhe: str = ""


@dataclass
class RelatorioBatimento:
    resultados: list = field(default_factory=list)
    alertas: list = field(default_factory=list)

    @property
    def aprovado(self) -> bool:
        return all(r.ok for r in self.resultados)

    def linhas_log(self) -> list:
        linhas = []
        linhas.append("─" * 50)
        linhas.append("📊  BATIMENTO DE VALORES")
        linhas.append("─" * 50)
        for r in self.resultados:
            status = "✅" if r.ok else "⚠️ "
            linhas.append(
                f"{status}  {r.tributo:<20} "
                f"ZFI: R$ {r.valor_zfi:>12,.2f}  |  "
                f"Conta: R$ {r.valor_conta:>12,.2f}  |  "
                f"Dif: R$ {r.diferenca:>10,.2f}"
            )
            if r.detalhe:
                linhas.append(f"     → {r.detalhe}")
        for a in self.alertas:
            linhas.append(f"⚠️   {a}")
        if self.aprovado:
            linhas.append("✅  Batimento aprovado — valores dentro da tolerância.")
        else:
            linhas.append("⚠️   Batimento com diferenças — revise antes de enviar.")
        linhas.append("─" * 50)
        return linhas


TOLERANCIA = 0.10  # R$ 0,10 de tolerância por arredondamento


def executar_batimento(
    df_zfi: pd.DataFrame,
    df_irrf: Optional[pd.DataFrame] = None,
    df_inss: Optional[pd.DataFrame] = None,
    df_pisc: Optional[pd.DataFrame] = None,
) -> RelatorioBatimento:
    """
    Cruza valores do ZFI0066 com as planilhas de conta.

    ZFI0066 → valores negativos para tributos (deduções),
    planilhas de conta → Montante MI negativo (saída de caixa).
    Ambos são comparados em valor absoluto.
    """
    rel = RelatorioBatimento()

    # ── IRRF ──────────────────────────────────────────────────
    irrf_zfi = df_zfi["IRRF"].abs().sum() if "IRRF" in df_zfi.columns else 0.0

    if df_irrf is not None and "Montante MI" in df_irrf.columns:
        irrf_conta = df_irrf["Montante MI"].abs().sum()
        dif = irrf_zfi - irrf_conta
        rel.resultados.append(ResultadoBatimento(
            tributo="IRRF",
            valor_zfi=irrf_zfi,
            valor_conta=irrf_conta,
            diferenca=dif,
            ok=abs(dif) <= TOLERANCIA,
            detalhe="" if abs(dif) <= TOLERANCIA else
                    "Verifique estornos (ES/KR) que ajustam o saldo da conta."
        ))
    else:
        rel.alertas.append("IRRF: planilha 21131104 não carregada — batimento ignorado.")

    # ── INSS ──────────────────────────────────────────────────
    inss_zfi = df_zfi["INSS"].abs().sum() if "INSS" in df_zfi.columns else 0.0

    if df_inss is not None and "Montante MI" in df_inss.columns:
        inss_conta = df_inss["Montante MI"].abs().sum()
        dif = inss_zfi - inss_conta
        rel.resultados.append(ResultadoBatimento(
            tributo="INSS",
            valor_zfi=inss_zfi,
            valor_conta=inss_conta,
            diferenca=dif,
            ok=abs(dif) <= TOLERANCIA,
        ))
    else:
        rel.alertas.append("INSS: planilha 21131302 não carregada — batimento ignorado.")

    # ── PIS + COFINS + CSLL ────────────────────────────────────
    pis   = df_zfi["PIS"].abs().sum()   if "PIS"    in df_zfi.columns else 0.0
    cof   = df_zfi["COFINS"].abs().sum() if "COFINS" in df_zfi.columns else 0.0
    csll  = df_zfi["CLL"].abs().sum()   if "CLL"    in df_zfi.columns else 0.0
    csrf_zfi = pis + cof + csll

    if df_pisc is not None and "Montante MI" in df_pisc.columns:
        csrf_conta = df_pisc["Montante MI"].abs().sum()
        dif = csrf_zfi - csrf_conta
        rel.resultados.append(ResultadoBatimento(
            tributo="PIS+COFINS+CSLL",
            valor_zfi=csrf_zfi,
            valor_conta=csrf_conta,
            diferenca=dif,
            ok=abs(dif) <= TOLERANCIA,
            detalhe="" if abs(dif) <= TOLERANCIA else
                    "Verifique se há KR/KZ/ZP que ajustam o saldo da conta 21131701."
        ))
    else:
        rel.alertas.append("PIS/COFINS/CSLL: planilha 21131701 não carregada.")

    # ── Totais ZFI por tipo PF/PJ ─────────────────────────────
    if "PF/PJ" in df_zfi.columns:
        n_pj = len(df_zfi[df_zfi["PF/PJ"] == "PJ"])
        n_pf = len(df_zfi[df_zfi["PF/PJ"] == "PF"])
        rel.alertas.append(
            f"ZFI0066: {n_pj} pagamentos PJ (→ R-4020) | {n_pf} pagamentos PF (→ R-4010)"
        )

    return rel
