"""
core/config_manager.py
Carrega e valida o config.json do projeto EFD-REINF.
"""

import json
import os
from pathlib import Path


BASE_DIR = Path(__file__).resolve().parent.parent


def carregar_config(caminho: str = None) -> dict:
    """Carrega o config.json. Aceita caminho absoluto ou relativo à raiz do projeto."""
    if caminho is None:
        caminho = BASE_DIR / "config" / "config.json"
    else:
        caminho = Path(caminho)
        if not caminho.is_absolute():
            caminho = BASE_DIR / caminho

    if not caminho.exists():
        raise FileNotFoundError(f"Arquivo de configuração não encontrado: {caminho}")

    with open(caminho, "r", encoding="utf-8") as f:
        config = json.load(f)

    _validar_config(config)
    return config


def _validar_config(config: dict):
    campos_obrigatorios = [
        "cnpj", "ambiente", "certificado", "senha_certificado",
        "contato_nome", "contato_cpf", "contato_email", "razao_social"
    ]
    ausentes = [c for c in campos_obrigatorios if not config.get(c)]
    if ausentes:
        raise ValueError(f"Campos obrigatórios ausentes no config.json: {', '.join(ausentes)}")

    ambientes_validos = ["producao_restrita", "producao"]
    if config["ambiente"] not in ambientes_validos:
        raise ValueError(
            f"Ambiente inválido: '{config['ambiente']}'. "
            f"Use um de: {ambientes_validos}"
        )

    cert_path = BASE_DIR / config["certificado"]
    if not cert_path.exists():
        raise FileNotFoundError(
            f"Certificado não encontrado: {cert_path}\n"
            "Verifique o campo 'certificado' no config.json."
        )


def get_tp_amb(config: dict) -> str:
    """Retorna o código de ambiente (1=Produção, 2=Produção Restrita)."""
    return "1" if config["ambiente"] == "producao" else "2"


def get_cert_path(config: dict) -> Path:
    return BASE_DIR / config["certificado"]
