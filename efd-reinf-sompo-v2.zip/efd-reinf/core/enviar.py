"""
core/enviar.py
Envia lote de eventos EFD-REINF ao WebService da Receita Federal
via SOAP 1.2 com certificado A1 (.pfx convertido para .crt/.key).
"""

import os
import ssl
import http.client
import tempfile
import subprocess
from pathlib import Path
from lxml import etree


# Endpoints por ambiente
ENDPOINTS = {
    "producao_restrita": {
        "host": "preprodefdr-reinf.receita.fazenda.gov.br",
        "path": "/REINF/RecepcaoLoteReinf.svc",
    },
    "producao": {
        "host": "reinf.receita.fazenda.gov.br",
        "path": "/REINF/RecepcaoLoteReinf.svc",
    },
}

SOAP_ACTION = "http://www.reinf.esocial.gov.br/WsRecepcaoLoteReinf/ReceberLoteEventos"


def _extrair_pem_do_pfx(pfx_path: Path, senha: str, tmp_dir: Path):
    """
    Usa OpenSSL (via subprocess) para extrair .crt e .key do .pfx.
    Retorna (cert_path, key_path) como strings.
    """
    cert_file = tmp_dir / "cert.crt"
    key_file  = tmp_dir / "chave.key"

    base_cmd = ["openssl", "pkcs12", "-in", str(pfx_path), "-passin", f"pass:{senha}"]

    # Extrair certificado
    subprocess.run(
        base_cmd + ["-clcerts", "-nokeys", "-out", str(cert_file)],
        check=True, capture_output=True
    )

    # Extrair chave privada (sem senha)
    subprocess.run(
        base_cmd + ["-nocerts", "-nodes", "-out", str(key_file)],
        check=True, capture_output=True
    )

    return str(cert_file), str(key_file)


def _validar_xml(xml_path: Path) -> bytes:
    """Parseia o XML assinado e retorna seus bytes. Lança exceção se mal formado."""
    with open(xml_path, "rb") as f:
        data = f.read()
    try:
        etree.fromstring(data)
    except etree.XMLSyntaxError as e:
        raise ValueError(f"XML inválido: {e}")
    return data


def _montar_soap(xml_bytes: bytes) -> str:
    """Monta o envelope SOAP 1.2 com o lote de eventos."""
    xml_str = xml_bytes.decode("utf-8")
    return f"""<?xml version="1.0" encoding="utf-8"?>
<soap:Envelope
  xmlns:soap="http://www.w3.org/2003/05/soap-envelope"
  xmlns:ns="http://www.reinf.esocial.gov.br/WsRecepcaoLoteReinf">
  <soap:Header/>
  <soap:Body>
    <ns:ReceberLoteEventos>
      <ns:loteEventos>
        <![CDATA[{xml_str}]]>
      </ns:loteEventos>
    </ns:ReceberLoteEventos>
  </soap:Body>
</soap:Envelope>"""


def enviar_lote(
    xml_assinado_path: Path,
    pfx_path: Path,
    senha: str,
    ambiente: str,
    output_dir: Path = None,
    log_callback=None,
) -> Path:
    """
    Envia o XML assinado para o WebService da Receita Federal.

    Parâmetros
    ----------
    xml_assinado_path : caminho do XML já assinado
    pfx_path          : caminho do certificado .pfx
    senha             : senha do .pfx
    ambiente          : 'producao_restrita' ou 'producao'
    output_dir        : onde salvar a resposta (padrão: mesma pasta do XML)
    log_callback      : função(str) para logar progresso na GUI

    Retorna
    -------
    Path do arquivo de resposta salvo.
    """
    def log(msg):
        if log_callback:
            log_callback(msg)

    if ambiente not in ENDPOINTS:
        raise ValueError(f"Ambiente inválido: '{ambiente}'")

    endpoint = ENDPOINTS[ambiente]
    log(f"🌐 Endpoint: {endpoint['host']}{endpoint['path']}")

    # Validar XML
    log("🔍 Validando XML assinado...")
    xml_bytes = _validar_xml(xml_assinado_path)
    log("✅ XML válido e bem formado.")

    # Extrair PEM em diretório temporário
    with tempfile.TemporaryDirectory() as tmp_dir:
        tmp_path = Path(tmp_dir)
        log("🔐 Extraindo certificado PEM...")
        try:
            cert_file, key_file = _extrair_pem_do_pfx(pfx_path, senha, tmp_path)
        except subprocess.CalledProcessError as e:
            raise RuntimeError(
                "Falha ao extrair certificado PEM via OpenSSL.\n"
                "Verifique se o OpenSSL está instalado e a senha está correta.\n"
                f"Detalhe: {e.stderr.decode()}"
            )
        log("✅ Certificado PEM extraído.")

        # Configurar SSL
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
        ctx.load_cert_chain(certfile=cert_file, keyfile=key_file)

        # Montar SOAP
        soap_body = _montar_soap(xml_bytes)
        headers = {
            "Content-Type": 'application/soap+xml; charset=utf-8; action="' + SOAP_ACTION + '"',
            "Accept": "application/soap+xml",
        }

        # Enviar
        log(f"📤 Enviando para {endpoint['host']}...")
        conn = http.client.HTTPSConnection(endpoint["host"], context=ctx, timeout=60)
        conn.request("POST", endpoint["path"], body=soap_body.encode("utf-8"), headers=headers)
        response = conn.getresponse()
        response_data = response.read()
        conn.close()

        log(f"📬 Resposta HTTP: {response.status} {response.reason}")

    # Salvar resposta
    if output_dir is None:
        output_dir = xml_assinado_path.parent

    from datetime import datetime
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    resp_path = output_dir / f"resposta_receita_{ts}.xml"

    with open(resp_path, "wb") as f:
        f.write(response_data)

    log(f"💾 Resposta salva em: {resp_path.name}")

    # Tentar parsear e exibir protocolo
    try:
        resp_tree = etree.fromstring(response_data)
        log("✅ Resposta XML recebida com sucesso.")
    except Exception:
        log("⚠️  Resposta não é um XML válido — verifique o arquivo de resposta.")

    return resp_path
