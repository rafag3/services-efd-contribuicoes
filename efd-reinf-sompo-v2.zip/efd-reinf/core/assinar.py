"""
core/assinar.py
Assina XMLs no padrão XMLDSig (enveloped) exigido pela Receita Federal
para envio da EFD-REINF.

Padrão obrigatório:
  - Algoritmo: RSA-SHA1 (exigido pelo webservice da RF)
  - Digest:    SHA-1
  - C14N:      http://www.w3.org/TR/2001/REC-xml-c14n-20010315
  - Método:    Enveloped Signature
  - Referência: URI="#<id_do_evento>"
"""

import base64
import hashlib
from copy import deepcopy
from pathlib import Path
from lxml import etree
from cryptography.hazmat.primitives.serialization import pkcs12
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import padding
from cryptography.hazmat.backends import default_backend
from cryptography.x509 import Certificate

# Namespaces XMLDSig
NS_DS = "http://www.w3.org/2000/09/xmldsig#"
NS_REINF = "http://www.reinf.esocial.gov.br/schemas/evtInfoContribuinte/v2_01_02"

# Algoritmos
ALG_RSA_SHA1  = "http://www.w3.org/2000/09/xmldsig#rsa-sha1"
ALG_SHA1      = "http://www.w3.org/2000/09/xmldsig#sha1"
ALG_C14N      = "http://www.w3.org/TR/2001/REC-xml-c14n-20010315"
ALG_ENVELOPED = "http://www.w3.org/2000/09/xmldsig#enveloped-signature"


def _carregar_pfx(cert_path: Path, senha: str):
    """Carrega chave privada e certificado a partir de um .pfx."""
    with open(cert_path, "rb") as f:
        pfx_data = f.read()

    private_key, certificate, _ = pkcs12.load_key_and_certificates(
        pfx_data,
        senha.encode("utf-8"),
        backend=default_backend()
    )
    return private_key, certificate


def _cert_para_base64(certificate: Certificate) -> str:
    """Serializa o certificado X.509 em Base64 (sem headers PEM)."""
    der_bytes = certificate.public_bytes(serialization.Encoding.DER)
    return base64.b64encode(der_bytes).decode("ascii")


def _c14n(element) -> bytes:
    """Aplica canonicalização C14N exclusiva ao elemento."""
    output = etree.tostring(element, method="c14n", exclusive=False, with_comments=False)
    return output


def _sha1_base64(data: bytes) -> str:
    """Retorna SHA-1 de `data` em Base64."""
    digest = hashlib.sha1(data).digest()
    return base64.b64encode(digest).decode("ascii")


def assinar_xml(xml_path: Path, cert_path: Path, senha: str, output_path: Path = None) -> Path:
    """
    Assina um XML da EFD-REINF no padrão XMLDSig enveloped exigido pela Receita Federal.

    Parâmetros
    ----------
    xml_path   : caminho do XML original (ex: xmls/R-1000.xml)
    cert_path  : caminho do certificado .pfx
    senha      : senha do certificado
    output_path: onde salvar o XML assinado (padrão: mesmo nome com sufixo _assinado)

    Retorna
    -------
    Path do arquivo XML assinado gerado.
    """
    # --- 1. Carregar certificado ---
    private_key, certificate = _carregar_pfx(cert_path, senha)

    # --- 2. Parsear XML original ---
    parser = etree.XMLParser(remove_blank_text=True)
    with open(xml_path, "rb") as f:
        tree = etree.parse(f, parser)
    root = tree.getroot()

    # --- 3. Localizar o elemento evento (filho direto de <Reinf>) ---
    # O elemento assinado é o filho de <Reinf> que contém o atributo 'Id'
    evento = None
    for child in root:
        if child.get("id") or child.get("Id"):
            evento = child
            break

    if evento is None:
        raise ValueError(
            "Não foi encontrado elemento com atributo 'id' dentro de <Reinf>. "
            "Certifique-se de que o XML possui o atributo id no elemento do evento."
        )

    ref_id = evento.get("id") or evento.get("Id")

    # --- 4. Calcular DigestValue (SHA-1 do C14N do evento, sem Signature) ---
    evento_c14n = _c14n(evento)
    digest_value = _sha1_base64(evento_c14n)

    # --- 5. Montar elemento <SignedInfo> ---
    signed_info = etree.Element(f"{{{NS_DS}}}SignedInfo")

    cm = etree.SubElement(signed_info, f"{{{NS_DS}}}CanonicalizationMethod")
    cm.set("Algorithm", ALG_C14N)

    sm = etree.SubElement(signed_info, f"{{{NS_DS}}}SignatureMethod")
    sm.set("Algorithm", ALG_RSA_SHA1)

    ref = etree.SubElement(signed_info, f"{{{NS_DS}}}Reference")
    ref.set("URI", f"#{ref_id}")

    transforms = etree.SubElement(ref, f"{{{NS_DS}}}Transforms")
    t1 = etree.SubElement(transforms, f"{{{NS_DS}}}Transform")
    t1.set("Algorithm", ALG_ENVELOPED)
    t2 = etree.SubElement(transforms, f"{{{NS_DS}}}Transform")
    t2.set("Algorithm", ALG_C14N)

    dm = etree.SubElement(ref, f"{{{NS_DS}}}DigestMethod")
    dm.set("Algorithm", ALG_SHA1)

    dv = etree.SubElement(ref, f"{{{NS_DS}}}DigestValue")
    dv.text = digest_value

    # --- 6. Assinar C14N do <SignedInfo> com RSA-SHA1 ---
    signed_info_c14n = _c14n(signed_info)
    raw_signature = private_key.sign(
        signed_info_c14n,
        padding.PKCS1v15(),
        hashes.SHA1()
    )
    signature_b64 = base64.b64encode(raw_signature).decode("ascii")

    # --- 7. Montar elemento <Signature> completo ---
    signature_elem = etree.Element(f"{{{NS_DS}}}Signature")
    signature_elem.append(signed_info)

    sv = etree.SubElement(signature_elem, f"{{{NS_DS}}}SignatureValue")
    sv.text = signature_b64

    key_info = etree.SubElement(signature_elem, f"{{{NS_DS}}}KeyInfo")
    x509_data = etree.SubElement(key_info, f"{{{NS_DS}}}X509Data")
    x509_cert = etree.SubElement(x509_data, f"{{{NS_DS}}}X509Certificate")
    x509_cert.text = _cert_para_base64(certificate)

    # --- 8. Inserir <Signature> como último filho de <Reinf> ---
    root.append(signature_elem)

    # --- 9. Salvar XML assinado ---
    if output_path is None:
        stem = xml_path.stem
        output_path = xml_path.parent / f"{stem}_assinado.xml"

    with open(output_path, "wb") as f:
        f.write(etree.tostring(
            root,
            pretty_print=True,
            xml_declaration=True,
            encoding="UTF-8"
        ))

    return output_path
