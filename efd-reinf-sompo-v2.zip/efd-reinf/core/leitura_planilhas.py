"""
core/leitura_planilhas.py
Lê e normaliza as planilhas SAP para alimentar os geradores de eventos EFD-REINF.

Planilhas suportadas:
  ZFI0066-AAAAMM.xlsx     → Pagamentos consolidados (fonte principal R-4010/R-4020)
  21131104-AAAAMM.xlsx    → IRRF de Terceiros a Recolher (validação)
  21131302-AAAAMM.xlsx    → INSS Retido de Terceiros (R-2010)
  21131701-AAAAMM.xlsx    → PIS/COFINS/CSLL Retido de Terceiros (validação)
"""

import re
import pandas as pd
from pathlib import Path
from typing import Optional


# ─────────────────────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────────────────────

def _limpar_cnpj_cpf(valor: str) -> str:
    """Remove formatação de CNPJ/CPF, mantendo só dígitos."""
    return re.sub(r"[.\-/\s]", "", str(valor)).strip()


def _detectar_arquivo(pasta: Path, prefixo: str, competencia: str) -> Optional[Path]:
    """
    Localiza arquivo pelo prefixo de conta + competência (AAAAMM).
    Aceita variações de espaço/hífen no nome.
    Ex: '21131104 - 202606.xlsx' ou '21131104-202606.xlsx'
    """
    for arq in pasta.glob("*.xlsx"):
        nome = arq.stem.replace(" ", "").replace("-", "")
        if prefixo in nome and competencia in nome:
            return arq
    return None


def _detectar_zfi(pasta: Path, competencia: str) -> Optional[Path]:
    for arq in pasta.glob("*.xlsx"):
        if "ZFI0066" in arq.name and competencia in arq.name:
            return arq
    return None


# ─────────────────────────────────────────────────────────────
# Leitores individuais
# ─────────────────────────────────────────────────────────────

def ler_zfi0066(path: Path) -> pd.DataFrame:
    """
    Lê ZFI0066-AAAAMM.xlsx.
    Header real na linha 3 (índice 3), linha 4 é totalizador → skip.
    Retorna apenas linhas com pelo menos um tributo != 0.
    """
    df = pd.read_excel(
        path, engine="openpyxl",
        sheet_name="ZFI0066",
        header=3,
        skiprows=[4],
        dtype=str
    )
    df.columns = [str(c).strip() for c in df.columns]

    # Colunas de tributos
    tributos = ["INSS", "IRRF", "PIS", "COFINS", "CLL"]
    for col in tributos:
        if col in df.columns:
            df[col] = pd.to_numeric(df[col], errors="coerce").fillna(0.0)

    # Valor Bruto
    if "Valor Bruto" in df.columns:
        df["Valor Bruto"] = pd.to_numeric(df["Valor Bruto"], errors="coerce").fillna(0.0)

    # Filtrar linhas com algum tributo != 0
    cols_existentes = [c for c in tributos if c in df.columns]
    df = df[df[cols_existentes].abs().sum(axis=1) > 0].copy()

    # Limpar CNPJ/CPF
    if "CNPJ/CPF" in df.columns:
        df["CNPJ/CPF"] = df["CNPJ/CPF"].apply(_limpar_cnpj_cpf)
    if "CNPJ Filial" in df.columns:
        df["CNPJ Filial"] = df["CNPJ Filial"].apply(_limpar_cnpj_cpf)

    # Normalizar PF/PJ
    if "PF/PJ" in df.columns:
        df["PF/PJ"] = df["PF/PJ"].astype(str).str.strip().str.upper()

    # Código de retenção IRRF como int
    if "Código Retenção IRRF" in df.columns:
        df["Código Retenção IRRF"] = (
            pd.to_numeric(df["Código Retenção IRRF"], errors="coerce")
            .fillna(0).astype(int)
        )

    df = df.reset_index(drop=True)
    return df


def ler_conta_retencao(path: Path, tipos_doc: list = None) -> pd.DataFrame:
    """
    Lê planilhas de conta (21131104, 21131302, 21131701).
    tipos_doc: lista de tipos a manter. Padrão: ['CD'] (retenções).
    """
    if tipos_doc is None:
        tipos_doc = ["CD"]

    df = pd.read_excel(path, engine="openpyxl", sheet_name="Sheet1", header=0)

    # Filtrar tipo de documento
    if "Tipo de documento" in df.columns:
        df = df[df["Tipo de documento"].isin(tipos_doc)].copy()

    # Normalizar montante
    if "Montante MI" in df.columns:
        df["Montante MI"] = pd.to_numeric(df["Montante MI"], errors="coerce").fillna(0.0)

    # Limpar CPF/CNPJ
    if "CPF/CNPJ" in df.columns:
        df["CPF/CNPJ"] = df["CPF/CNPJ"].apply(_limpar_cnpj_cpf)

    # Data lançamento
    if "Data lançamento" in df.columns:
        df["Data lançamento"] = pd.to_datetime(df["Data lançamento"], errors="coerce")

    df = df.reset_index(drop=True)
    return df


# ─────────────────────────────────────────────────────────────
# Carregador principal
# ─────────────────────────────────────────────────────────────

class PlanilhasMes:
    """
    Carrega e valida todas as planilhas de uma competência.

    Uso:
        pm = PlanilhasMes(pasta=Path('dados'), competencia='202606')
        pm.carregar()
        print(pm.resumo())
    """

    def __init__(self, pasta: Path, competencia: str):
        self.pasta = Path(pasta)
        self.competencia = competencia  # formato AAAAMM

        self.zfi: Optional[pd.DataFrame] = None
        self.irrf: Optional[pd.DataFrame] = None
        self.inss: Optional[pd.DataFrame] = None
        self.pisc: Optional[pd.DataFrame] = None

        self._erros: list = []
        self._avisos: list = []

    def carregar(self, log=None):
        """Carrega todos os arquivos. log: função(str) opcional."""
        def _log(msg):
            if log:
                log(msg)

        # ZFI0066
        arq_zfi = _detectar_zfi(self.pasta, self.competencia)
        if arq_zfi:
            _log(f"📂 ZFI0066: {arq_zfi.name}")
            self.zfi = ler_zfi0066(arq_zfi)
            _log(f"   ✅ {len(self.zfi)} linhas com tributos")
        else:
            self._erros.append("ZFI0066 não encontrado.")
            _log(f"❌ ZFI0066-{self.competencia}.xlsx não encontrado na pasta.")

        # IRRF (21131104)
        arq_irrf = _detectar_arquivo(self.pasta, "21131104", self.competencia)
        if arq_irrf:
            _log(f"📂 IRRF: {arq_irrf.name}")
            self.irrf = ler_conta_retencao(arq_irrf)
            _log(f"   ✅ {len(self.irrf)} linhas (tipo CD)")
        else:
            self._avisos.append("21131104 (IRRF) não encontrado — validação parcial.")
            _log(f"⚠️  21131104-{self.competencia} não encontrado.")

        # INSS (21131302)
        arq_inss = _detectar_arquivo(self.pasta, "21131302", self.competencia)
        if arq_inss:
            _log(f"📂 INSS: {arq_inss.name}")
            self.inss = ler_conta_retencao(arq_inss)
            _log(f"   ✅ {len(self.inss)} linhas (tipo CD)")
        else:
            self._avisos.append("21131302 (INSS) não encontrado.")
            _log(f"⚠️  21131302-{self.competencia} não encontrado.")

        # PIS/COFINS/CSLL (21131701)
        arq_pisc = _detectar_arquivo(self.pasta, "21131701", self.competencia)
        if arq_pisc:
            _log(f"📂 PIS/COFINS/CSLL: {arq_pisc.name}")
            self.pisc = ler_conta_retencao(arq_pisc)
            _log(f"   ✅ {len(self.pisc)} linhas (tipo CD)")
        else:
            self._avisos.append("21131701 (PIS/COFINS/CSLL) não encontrado.")
            _log(f"⚠️  21131701-{self.competencia} não encontrado.")

    @property
    def valido(self) -> bool:
        return len(self._erros) == 0 and self.zfi is not None

    def resumo(self) -> dict:
        r = {"competencia": self.competencia, "erros": self._erros, "avisos": self._avisos}
        if self.zfi is not None:
            r["zfi_linhas"] = len(self.zfi)
            r["zfi_pj"] = len(self.zfi[self.zfi["PF/PJ"] == "PJ"])
            r["zfi_pf"] = len(self.zfi[self.zfi["PF/PJ"] == "PF"])
        if self.irrf is not None:
            r["irrf_linhas"] = len(self.irrf)
        if self.inss is not None:
            r["inss_linhas"] = len(self.inss)
        if self.pisc is not None:
            r["pisc_linhas"] = len(self.pisc)
        return r
